import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  Platform,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTransactions } from '../context/TransactionContext';
import { useAuth } from '../context/AuthContext';
import { colors } from '../theme/colors';
import { CATEGORIES } from '../data/categories';
import { SegmentControl } from '../components/SegmentControl';
import { DonutChart } from '../components/DonutChart';
import { BarComparisonChart } from '../components/BarComparisonChart';
import { StatCard } from '../components/SummaryCard';
import { EmptyState } from '../components/EmptyState';
import {
  filterTransactionsByPeriod,
  calculateTotals,
  calculateCategoryBreakdown,
} from '../utils/calculations';
import { formatCurrency } from '../utils/currency';

export const AnalysisScreen = ({ navigation }) => {
  const { transactions } = useTransactions();
  const { isAdmin } = useAuth();
  const [period, setPeriod] = useState('monthly');
  const [breakdownType, setBreakdownType] = useState('expense');

  // Filter transactions by selected period
  const periodTransactions = useMemo(() => {
    return filterTransactionsByPeriod(transactions, period);
  }, [transactions, period]);

  // Totals for this period
  const totals = useMemo(() => {
    return calculateTotals(periodTransactions);
  }, [periodTransactions]);

  // Category breakdown for selected breakdownType
  const categoryBreakdown = useMemo(() => {
    return calculateCategoryBreakdown(periodTransactions, CATEGORIES, breakdownType);
  }, [periodTransactions, breakdownType]);

  const activeTotalForBreakdown = breakdownType === 'expense' ? totals.expense : totals.income;

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header Bar */}
        <View style={styles.headerBar}>
          <TouchableOpacity
            onPress={() => navigation.openDrawer()}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.drawerToggleBtn}
          >
            <Ionicons name="menu-outline" size={26} color={colors.textPrimary} />
          </TouchableOpacity>
          <View style={styles.headerTitleWrap}>
            <Text style={styles.headerTitle}>Financial Analysis</Text>
            <Text style={styles.headerSubtitle}>
              {isAdmin ? 'Platform-wide Analytics' : 'Spending & Income Intelligence'}
            </Text>
          </View>
          <View style={{ width: 38 }} />
        </View>

        {/* Period Selector Tabs */}
        <View style={styles.segmentContainer}>
          <SegmentControl
            options={[
              { label: 'Daily', value: 'daily' },
              { label: 'Weekly', value: 'weekly' },
              { label: 'Monthly', value: 'monthly' },
            ]}
            selectedValue={period}
            onSelect={setPeriod}
          />
        </View>

        {/* Summary Metric Cards */}
        <View style={styles.statsRow}>
          <StatCard
            title="TOTAL INCOME"
            amount={totals.income}
            icon="arrow-down-circle"
            type="income"
            subtitle={`${periodTransactions.filter((t) => t.type === 'income').length} deposits`}
          />
          <StatCard
            title="TOTAL EXPENSE"
            amount={totals.expense}
            icon="arrow-up-circle"
            type="expense"
            subtitle={`${periodTransactions.filter((t) => t.type === 'expense').length} payments`}
          />
        </View>

        <View style={styles.fullWidthStatCard}>
          <View style={styles.balanceHeader}>
            <View>
              <Text style={styles.balanceLabel}>Current Period Net Balance</Text>
              <Text
                style={[
                  styles.balanceValue,
                  { color: totals.balance >= 0 ? colors.income : colors.expense },
                ]}
              >
                {formatCurrency(totals.balance)}
              </Text>
            </View>
            <View
              style={[
                styles.balanceBadge,
                {
                  backgroundColor:
                    totals.balance >= 0 ? colors.incomeLight : colors.expenseLight,
                },
              ]}
            >
              <Ionicons
                name={totals.balance >= 0 ? 'trending-up' : 'trending-down'}
                size={16}
                color={totals.balance >= 0 ? colors.income : colors.expense}
                style={{ marginRight: 4 }}
              />
              <Text
                style={[
                  styles.balanceBadgeText,
                  { color: totals.balance >= 0 ? colors.income : colors.expense },
                ]}
              >
                {totals.savingsRate}% Saved
              </Text>
            </View>
          </View>
        </View>

        {/* Income vs Expense Cashflow Comparison */}
        <View style={styles.sectionWrap}>
          <BarComparisonChart income={totals.income} expense={totals.expense} />
        </View>

        {/* Category Breakdown Section */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Category Breakdown</Text>
          <View style={styles.typeToggleRow}>
            <TouchableOpacity
              onPress={() => setBreakdownType('expense')}
              style={[
                styles.typeToggleBtn,
                breakdownType === 'expense' && styles.typeToggleActiveExpense,
              ]}
            >
              <Text
                style={[
                  styles.typeToggleText,
                  breakdownType === 'expense' && styles.typeToggleTextActive,
                ]}
              >
                Expenses
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => setBreakdownType('income')}
              style={[
                styles.typeToggleBtn,
                breakdownType === 'income' && styles.typeToggleActiveIncome,
              ]}
            >
              <Text
                style={[
                  styles.typeToggleText,
                  breakdownType === 'income' && styles.typeToggleTextActive,
                ]}
              >
                Income
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Visual Donut Chart */}
        <View style={styles.cardContainer}>
          <DonutChart
            data={categoryBreakdown}
            total={activeTotalForBreakdown}
            centerTitle={breakdownType === 'expense' ? 'Total Expenses' : 'Total Inflows'}
            size={220}
            strokeWidth={26}
          />
        </View>

        {/* Category Rankings List */}
        <View style={styles.rankingsContainer}>
          <Text style={styles.rankingsTitle}>
            {breakdownType === 'expense' ? 'Top Expense Categories' : 'Income Sources'}
          </Text>

          {categoryBreakdown.filter((c) => c.total > 0).length === 0 ? (
            <EmptyState
              icon="pie-chart-outline"
              title={`No ${breakdownType === 'expense' ? 'Expenses' : 'Income'} in this period`}
              description={`There are no recorded ${breakdownType} transactions for the ${period} view.`}
            />
          ) : (
            categoryBreakdown
              .filter((c) => c.total > 0)
              .map((cat, index) => (
                <View key={cat.id || index} style={styles.categoryRankRow}>
                  <View style={[styles.rankBadge, { backgroundColor: cat.bgColor }]}>
                    <Ionicons name={cat.icon} size={18} color={cat.color} />
                  </View>
                  <View style={styles.rankInfo}>
                    <Text style={styles.rankName}>{cat.name}</Text>
                    <Text style={styles.rankCount}>
                      {cat.count} {cat.count === 1 ? 'record' : 'records'}
                    </Text>
                  </View>
                  <View style={styles.rankAmountWrap}>
                    <Text style={styles.rankAmount}>{formatCurrency(cat.total)}</Text>
                    <Text style={styles.rankPercentage}>{cat.percentage}%</Text>
                  </View>
                </View>
              ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
    paddingTop: Platform.OS === 'android' ? 30 : 0,
  },
  scrollContent: {
    paddingBottom: 40,
  },
  headerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  drawerToggleBtn: {
    padding: 6,
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  headerTitleWrap: {
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  headerSubtitle: {
    fontSize: 12,
    color: colors.textSecondary,
    fontWeight: '500',
    marginTop: 2,
  },
  segmentContainer: {
    paddingHorizontal: 16,
  },
  statsRow: {
    flexDirection: 'row',
    paddingHorizontal: 10,
    marginTop: 6,
  },
  fullWidthStatCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  balanceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  balanceLabel: {
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: '600',
    marginBottom: 4,
  },
  balanceValue: {
    fontSize: 22,
    fontWeight: '800',
  },
  balanceBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 12,
  },
  balanceBadgeText: {
    fontSize: 12,
    fontWeight: '700',
  },
  sectionWrap: {
    paddingHorizontal: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginTop: 18,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  typeToggleRow: {
    flexDirection: 'row',
    backgroundColor: '#F1F5F9',
    borderRadius: 10,
    padding: 3,
  },
  typeToggleBtn: {
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 8,
  },
  typeToggleActiveExpense: {
    backgroundColor: colors.expense,
  },
  typeToggleActiveIncome: {
    backgroundColor: colors.income,
  },
  typeToggleText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  typeToggleTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  cardContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 16,
    marginHorizontal: 16,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  rankingsContainer: {
    paddingHorizontal: 16,
    marginTop: 20,
  },
  rankingsTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: 12,
  },
  categoryRankRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 14,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  rankBadge: {
    width: 38,
    height: 38,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  rankInfo: {
    flex: 1,
  },
  rankName: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  rankCount: {
    fontSize: 11,
    color: colors.textMuted,
    marginTop: 2,
  },
  rankAmountWrap: {
    alignItems: 'flex-end',
  },
  rankAmount: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  rankPercentage: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textSecondary,
    marginTop: 2,
  },
});

export default AnalysisScreen;
