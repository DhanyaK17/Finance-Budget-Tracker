import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  Keyboard,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { colors } from '../theme/colors';
import { AppButton } from '../components/AppButton';
import { AppInput } from '../components/AppInput';
import { validateEmail, validatePassword } from '../utils/validation';

export const SignInScreen = ({ navigation }) => {
  const { login, quickDemoLogin } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [generalError, setGeneralError] = useState('');

  const handleSignIn = async () => {
    Keyboard.dismiss();
    if (isLoading) return;
    setGeneralError('');
    const newErrors = {};

    const emailCheck = validateEmail(email);
    if (!emailCheck.isValid) newErrors.email = emailCheck.message;

    const passCheck = validatePassword(password);
    if (!passCheck.isValid) newErrors.password = passCheck.message;

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsLoading(true);

    try {
      const res = await login(email, password);
      if (!res.success) {
        setGeneralError(res.message);
      }
    } catch (e) {
      setGeneralError('Sign in failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickDemo = async (role) => {
    Keyboard.dismiss();
    if (isLoading) return;
    setIsLoading(true);
    setGeneralError('');
    try {
      await quickDemoLogin(role);
    } catch (e) {
      setGeneralError('Quick demo login failed.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        enabled={Platform.OS === 'ios'}
        style={styles.keyboardContainer}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.contentGroup}>
            {/* Branding & Logo */}
            <View style={styles.brandContainer}>
              <View style={styles.logoBadge}>
                <Ionicons name="wallet" size={38} color="#FFFFFF" />
              </View>
              <Text style={styles.appName}>FinTrack</Text>
              <Text style={styles.appTagline}>Finance & Budget Tracker</Text>
            </View>

            {/* Welcome Card */}
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Sign In</Text>
              <Text style={styles.cardSubtitle}>
                Welcome back! Access your personal financial tracker.
              </Text>

              {generalError ? (
                <View style={styles.errorBanner}>
                  <Ionicons name="alert-circle" size={18} color={colors.expense} />
                  <Text style={styles.errorBannerText}>{generalError}</Text>
                </View>
              ) : null}

              <AppInput
                label="Email Address"
                placeholder="admin@finance.app or dhanya@finance.app"
                value={email}
                onChangeText={(txt) => {
                  setEmail(txt);
                  if (errors.email) setErrors((prev) => ({ ...prev, email: '' }));
                }}
                icon="mail-outline"
                keyboardType="email-address"
                autoCapitalize="none"
                error={errors.email}
              />

              <AppInput
                label="Password"
                placeholder="Enter your password"
                value={password}
                onChangeText={(txt) => {
                  setPassword(txt);
                  if (errors.password) setErrors((prev) => ({ ...prev, password: '' }));
                }}
                icon="lock-closed-outline"
                secureTextEntry
                error={errors.password}
              />

              <AppButton
                title="Sign In"
                onPress={handleSignIn}
                variant="primary"
                size="lg"
                loading={isLoading}
                style={styles.signInBtn}
              />

              {/* Sign Up Redirect */}
              <View style={styles.signUpPrompt}>
                <Text style={styles.signUpPromptText}>New to FinTrack? </Text>
                <TouchableOpacity
                  onPress={() => {
                    Keyboard.dismiss();
                    navigation.navigate('SignUp');
                  }}
                >
                  <Text style={styles.signUpLinkText}>Create Account</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
  },
  keyboardContainer: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 24,
  },
  contentGroup: {
    width: '100%',
    maxWidth: 440,
    alignSelf: 'center',
  },
  brandContainer: {
    alignItems: 'center',
    marginBottom: 28,
  },
  logoBadge: {
    width: 72,
    height: 72,
    borderRadius: 22,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 14,
    elevation: 8,
    marginBottom: 12,
  },
  appName: {
    fontSize: 26,
    fontWeight: '800',
    color: colors.textPrimary,
    letterSpacing: -0.5,
  },
  appTagline: {
    fontSize: 14,
    color: colors.textSecondary,
    fontWeight: '500',
    marginTop: 2,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    padding: 24,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 4,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  cardSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    marginBottom: 20,
    lineHeight: 18,
  },
  errorBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEF2F2',
    padding: 10,
    borderRadius: 10,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#FCA5A5',
  },
  errorBannerText: {
    fontSize: 12,
    color: colors.expense,
    marginLeft: 8,
    fontWeight: '500',
    flex: 1,
  },
  signInBtn: {
    marginTop: 6,
  },
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: colors.cardBorder,
  },
  dividerText: {
    fontSize: 11,
    fontWeight: '700',
    color: colors.textMuted,
    marginHorizontal: 10,
    letterSpacing: 0.5,
  },
  demoButtonsContainer: {
    gap: 10,
  },
  demoBtnCustomer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 14,
    backgroundColor: colors.primaryMuted,
    borderWidth: 1,
    borderColor: '#C7D2FE',
    gap: 8,
  },
  demoBtnCustomerText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.primary,
  },
  demoBtnAdmin: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 14,
    backgroundColor: '#F5F3FF',
    borderWidth: 1,
    borderColor: '#DDD6FE',
    gap: 8,
  },
  demoBtnAdminText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.badgeAdmin,
  },
  signUpPrompt: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  signUpPromptText: {
    fontSize: 13,
    color: colors.textSecondary,
  },
  signUpLinkText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.primary,
  },
});

export default SignInScreen;
