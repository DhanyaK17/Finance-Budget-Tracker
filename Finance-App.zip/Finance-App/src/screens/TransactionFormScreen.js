import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTransactions } from '../context/TransactionContext';
import { useAuth } from '../context/AuthContext';
import { colors } from '../theme/colors';
import { CATEGORIES } from '../data/categories';
import { AppButton } from '../components/AppButton';
import { AppInput } from '../components/AppInput';
import { validateTransaction } from '../utils/validation';
import { toLocalDateString } from '../utils/dateHelpers';

export const TransactionFormScreen = ({ route, navigation }) => {
  const { addTransaction, editTransaction } = useTransactions();
  const { isAdmin } = useAuth();

  const mode = route.params?.mode || 'create';
  const existingTx = route.params?.transaction || null;

  const [title, setTitle] = useState(existingTx?.title || '');
  const [amount, setAmount] = useState(existingTx ? String(existingTx.amount) : '');
  const [type, setType] = useState(existingTx?.type || 'expense');
  const [categoryId, setCategoryId] = useState(existingTx?.categoryId || 'food');
  const [date, setDate] = useState(existingTx?.date || toLocalDateString(new Date()));
  const [note, setNote] = useState(existingTx?.note || '');
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  // Route protection
  if (isAdmin) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.restrictedContainer}>
          <Ionicons name="lock-closed" size={64} color={colors.expense} />
          <Text style={styles.restrictedTitle}>Access Restricted</Text>
          <Text style={styles.restrictedText}>
            Adding and editing transactions is restricted to Customer accounts.
          </Text>
          <AppButton
            title="Go Back"
            onPress={() => navigation.goBack()}
            variant="primary"
            style={{ marginTop: 20 }}
          />
        </View>
      </SafeAreaView>
    );
  }

  // Update default category when type switches
  useEffect(() => {
    if (!existingTx) {
      if (type === 'income') {
        setCategoryId('salary');
      } else {
        setCategoryId('food');
      }
    }
  }, [type, existingTx]);

  const filteredCategories = CATEGORIES.filter((c) => c.type === type);

  const handleSave = async () => {
    const check = validateTransaction({ title, amount, type, categoryId, date });
    if (!check.isValid) {
      setErrors(check.errors);
      return;
    }

    setErrors({});
    setIsLoading(true);

    try {
      if (mode === 'edit' && existingTx?.id) {
        await editTransaction(existingTx.id, {
          title,
          amount: Number(amount),
          type,
          categoryId,
          date,
          note,
        });
      } else {
        await addTransaction({
          title,
          amount: Number(amount),
          type,
          categoryId,
          date,
          note,
        });
      }
      navigation.goBack();
    } catch (e) {
      Alert.alert('Error', 'Failed to save transaction. Please check your data.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        enabled={Platform.OS === 'ios'}
        style={{ flex: 1 }}
      >
        {/* Header Bar */}
        <View style={styles.headerBar}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Ionicons name="close" size={26} color={colors.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>
            {mode === 'edit' ? 'Edit Transaction' : 'New Transaction'}
          </Text>
          <View style={{ width: 26 }} />
        </View>

        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Income vs Expense Selector */}
          <View style={styles.typeToggleWrap}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => setType('expense')}
              style={[
                styles.typeBtn,
                type === 'expense' && styles.typeBtnExpenseActive,
              ]}
            >
              <Ionicons
                name="arrow-up-circle"
                size={18}
                color={type === 'expense' ? '#FFFFFF' : colors.textSecondary}
              />
              <Text
                style={[
                  styles.typeBtnText,
                  type === 'expense' && styles.typeBtnTextActive,
                ]}
              >
                Expense
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => setType('income')}
              style={[
                styles.typeBtn,
                type === 'income' && styles.typeBtnIncomeActive,
              ]}
            >
              <Ionicons
                name="arrow-down-circle"
                size={18}
                color={type === 'income' ? '#FFFFFF' : colors.textSecondary}
              />
              <Text
                style={[
                  styles.typeBtnText,
                  type === 'income' && styles.typeBtnTextActive,
                ]}
              >
                Income
              </Text>
            </TouchableOpacity>
          </View>

          {/* Amount Input */}
          <AppInput
            label="Amount (in ₹) *"
            placeholder="0.00"
            value={amount}
            onChangeText={(txt) => {
              setAmount(txt);
              if (errors.amount) setErrors((prev) => ({ ...prev, amount: '' }));
            }}
            icon="cash-outline"
            keyboardType="numeric"
            error={errors.amount}
            inputStyle={styles.amountInput}
          />

          {/* Title Input */}
          <AppInput
            label="Title / Description *"
            placeholder="e.g. Grocery shopping, Client payment"
            value={title}
            onChangeText={(txt) => {
              setTitle(txt);
              if (errors.title) setErrors((prev) => ({ ...prev, title: '' }));
            }}
            icon="pencil-outline"
            error={errors.title}
          />

          {/* Category Selector */}
          <View style={styles.categorySection}>
            <Text style={styles.fieldLabel}>Select Category *</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.categoryPillsScroll}
            >
              {filteredCategories.map((cat) => {
                const isSelected = categoryId === cat.id;
                return (
                  <TouchableOpacity
                    key={cat.id}
                    activeOpacity={0.75}
                    onPress={() => setCategoryId(cat.id)}
                    style={[
                      styles.categoryPill,
                      isSelected && {
                        backgroundColor: cat.color,
                        borderColor: cat.color,
                      },
                    ]}
                  >
                    <Ionicons
                      name={cat.icon}
                      size={16}
                      color={isSelected ? '#FFFFFF' : cat.color}
                      style={{ marginRight: 6 }}
                    />
                    <Text
                      style={[
                        styles.categoryPillText,
                        isSelected && { color: '#FFFFFF', fontWeight: '700' },
                      ]}
                    >
                      {cat.name}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
            {errors.categoryId ? (
              <Text style={styles.errorText}>{errors.categoryId}</Text>
            ) : null}
          </View>

          {/* Date Input */}
          <View style={styles.dateSection}>
            <AppInput
              label="Transaction Date (YYYY-MM-DD) *"
              placeholder="2026-10-28"
              value={date}
              onChangeText={(txt) => {
                setDate(txt);
                if (errors.date) setErrors((prev) => ({ ...prev, date: '' }));
              }}
              icon="calendar-outline"
              error={errors.date}
            />
            <TouchableOpacity
              onPress={() => setDate(toLocalDateString(new Date()))}
              style={styles.todayBtn}
            >
              <Text style={styles.todayBtnText}>Use Today's Date</Text>
            </TouchableOpacity>
          </View>

          {/* Optional Note */}
          <AppInput
            label="Additional Notes (Optional)"
            placeholder="Add extra details, merchant, or tags..."
            value={note}
            onChangeText={setNote}
            icon="document-text-outline"
            multiline
            numberOfLines={3}
          />

          {/* Action Buttons */}
          <View style={styles.actionRow}>
            <AppButton
              title="Cancel"
              onPress={() => navigation.goBack()}
              variant="outline"
              size="lg"
              style={{ flex: 1 }}
            />
            <AppButton
              title={mode === 'edit' ? 'Save Changes' : 'Add Transaction'}
              onPress={handleSave}
              variant="primary"
              size="lg"
              loading={isLoading}
              style={{ flex: 1.5 }}
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
    paddingTop: Platform.OS === 'android' ? 30 : 0,
  },
  headerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.cardBorder,
    backgroundColor: '#FFFFFF',
  },
  backBtn: {
    padding: 2,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  typeToggleWrap: {
    flexDirection: 'row',
    backgroundColor: colors.surfaceSubtle,
    borderRadius: 16,
    padding: 4,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  typeBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    gap: 8,
  },
  typeBtnExpenseActive: {
    backgroundColor: colors.expense,
  },
  typeBtnIncomeActive: {
    backgroundColor: colors.income,
  },
  typeBtnText: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textSecondary,
  },
  typeBtnTextActive: {
    color: '#FFFFFF',
  },
  amountInput: {
    fontSize: 20,
    fontWeight: '800',
  },
  fieldLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textPrimary,
    marginBottom: 8,
  },
  categorySection: {
    marginBottom: 16,
  },
  categoryPillsScroll: {
    gap: 8,
    paddingVertical: 4,
  },
  categoryPill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 9,
    paddingHorizontal: 14,
    borderRadius: 14,
    backgroundColor: '#FFFFFF',
    borderWidth: 1.2,
    borderColor: colors.cardBorder,
  },
  categoryPillText: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  errorText: {
    fontSize: 12,
    color: colors.expense,
    marginTop: 4,
    fontWeight: '500',
  },
  dateSection: {
    position: 'relative',
  },
  todayBtn: {
    alignSelf: 'flex-end',
    marginTop: -10,
    marginBottom: 14,
    paddingHorizontal: 4,
  },
  todayBtnText: {
    fontSize: 12,
    color: '#0D9488',
    fontWeight: '700',
  },
  actionRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 10,
  },
  restrictedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  restrictedTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
    marginTop: 16,
    marginBottom: 8,
  },
  restrictedText: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
  },
});

export default TransactionFormScreen;
