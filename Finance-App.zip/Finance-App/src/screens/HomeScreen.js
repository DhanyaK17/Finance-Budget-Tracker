import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Platform,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { useTransactions } from '../context/TransactionContext';
import { colors } from '../theme/colors';
import { HeroBalanceCard, StatCard } from '../components/SummaryCard';
import { TransactionItem } from '../components/TransactionItem';
import { SegmentControl } from '../components/SegmentControl';
import { EmptyState } from '../components/EmptyState';
import { BarComparisonChart } from '../components/BarComparisonChart';
import { DonutChart } from '../components/DonutChart';
import { CATEGORIES } from '../data/categories';
import {
  calculateTotals,
  calculatePeriodReports,
  filterTransactionsByPeriod,
  calculateCategoryBreakdown,
} from '../utils/calculations';

export const HomeScreen = ({ navigation }) => {
  const { currentUser, isAdmin, isCustomer } = useAuth();
  const { transactions, deleteTransaction } = useTransactions();
  const [selectedReportPeriod, setSelectedReportPeriod] = useState('monthly');

  // Category breakdown for active period (for Admin aggregated summary)
  const categoryBreakdown = useMemo(() => {
    const periodTx = filterTransactionsByPeriod(transactions, selectedReportPeriod);
    return calculateCategoryBreakdown(periodTx, CATEGORIES, 'expense');
  }, [transactions, selectedReportPeriod]);

  // Overall and period totals
  const overallTotals = useMemo(() => calculateTotals(transactions), [transactions]);
  const periodReports = useMemo(() => calculatePeriodReports(transactions), [transactions]);

  // Current active period calculations
  const activePeriodTotals = useMemo(() => {
    switch (selectedReportPeriod) {
      case 'daily':
        return periodReports.daily;
      case 'weekly':
        return periodReports.weekly;
      case 'monthly':
      default:
        return periodReports.monthly;
    }
  }, [selectedReportPeriod, periodReports]);

  // Recent transactions (most recent 6)
  const recentTransactions = useMemo(() => {
    return transactions.slice(0, 6);
  }, [transactions]);

  // Handle transaction delete
  const handleDeleteTransaction = (transaction) => {
    Alert.alert(
      'Delete Transaction',
      `Are you sure you want to delete "${transaction.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            await deleteTransaction(transaction.id);
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Top Header Bar */}
        <View style={styles.headerBar}>
          <TouchableOpacity
            onPress={() => navigation.openDrawer()}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.drawerToggleBtn}
          >
            <Ionicons name="menu-outline" size={26} color={colors.textPrimary} />
          </TouchableOpacity>

          <View style={styles.brandTitleWrap}>
            <Text style={styles.brandAppName}>FinTrack</Text>
            <Text style={styles.welcomeText}>
              Welcome, <Text style={styles.userNameHighlight}>{currentUser?.name || 'User'}</Text>
            </Text>
          </View>

          <TouchableOpacity
            onPress={() => {
              if (isCustomer) {
                navigation.navigate('MainTabs', { screen: 'ProfileTab' });
              } else {
                navigation.navigate('MainTabs', { screen: 'AnalysisTab' });
              }
            }}
            style={[
              styles.avatarBtn,
              { backgroundColor: isAdmin ? colors.badgeAdmin : colors.primary },
            ]}
          >
            <Ionicons
              name={isAdmin ? 'shield-checkmark' : 'person'}
              size={18}
              color="#FFFFFF"
            />
          </TouchableOpacity>
        </View>

        {/* Role Banner if Admin */}
        {isAdmin && (
          <View style={styles.adminBanner}>
            <Ionicons name="information-circle" size={18} color={colors.badgeAdmin} />
            <Text style={styles.adminBannerText}>
              Logged in as Admin. Viewing aggregated platform financial summary.
            </Text>
          </View>
        )}

        {/* Hero Balance Card */}
        <HeroBalanceCard
          balance={overallTotals.balance}
          income={overallTotals.income}
          expense={overallTotals.expense}
          savingsRate={overallTotals.savingsRate}
          userName={currentUser?.name}
          role={currentUser?.role}
          onAddPress={
            isCustomer ? () => navigation.navigate('TransactionForm', { mode: 'create' }) : null
          }
          onAnalyticsPress={() => navigation.navigate('MainTabs', { screen: 'AnalysisTab' })}
        />

        {/* Period Financial Reports Section */}
        <View style={styles.sectionHeaderRow}>
          <View>
            <Text style={styles.sectionTitle}>Financial Reports</Text>
            <Text style={styles.sectionSubtitle}>
              Breakdown for {selectedReportPeriod} period
            </Text>
          </View>
        </View>

        {/* Segment Control for Daily / Weekly / Monthly */}
        <View style={styles.segmentWrap}>
          <SegmentControl
            options={[
              { label: 'Daily', value: 'daily' },
              { label: 'Weekly', value: 'weekly' },
              { label: 'Monthly', value: 'monthly' },
            ]}
            selectedValue={selectedReportPeriod}
            onSelect={setSelectedReportPeriod}
          />
        </View>

        {/* Period Stat Cards Grid */}
        <View style={styles.statsGrid}>
          <View style={styles.gridRow}>
            <StatCard
              title={`${selectedReportPeriod.toUpperCase()} INCOME`}
              amount={activePeriodTotals.income}
              icon="arrow-down-circle"
              type="income"
              subtitle={`${activePeriodTotals.transactionCount} transactions`}
            />
            <StatCard
              title={`${selectedReportPeriod.toUpperCase()} EXPENSE`}
              amount={activePeriodTotals.expense}
              icon="arrow-up-circle"
              type="expense"
              subtitle="Outflow"
            />
          </View>
          <View style={styles.gridRow}>
            <StatCard
              title="NET BALANCE"
              amount={activePeriodTotals.balance}
              icon="wallet-outline"
              type={activePeriodTotals.balance >= 0 ? 'income' : 'expense'}
              subtitle={activePeriodTotals.balance >= 0 ? 'Surplus' : 'Deficit'}
            />
            <StatCard
              title="SAVINGS RATE"
              amount={activePeriodTotals.balance > 0 ? activePeriodTotals.balance : 0}
              icon="leaf-outline"
              type="savings"
              subtitle={`${activePeriodTotals.savingsRate}% of income`}
            />
          </View>
        </View>

        {/* Admin Aggregated Analytics: Income vs Expenses Chart & Category Breakdown */}
        {isAdmin && (
          <View style={styles.adminAnalyticsWrap}>
            <View style={styles.chartSectionWrap}>
              <BarComparisonChart
                income={activePeriodTotals.income}
                expense={activePeriodTotals.expense}
              />
            </View>

            <View style={styles.sectionHeaderRow}>
              <View>
                <Text style={styles.sectionTitle}>Category-Wise Expense Summary</Text>
                <Text style={styles.sectionSubtitle}>
                  Aggregated outflow for {selectedReportPeriod} period
                </Text>
              </View>
            </View>

            <View style={styles.donutCardContainer}>
              <DonutChart
                data={categoryBreakdown}
                total={activePeriodTotals.expense}
                centerTitle={`${selectedReportPeriod.charAt(0).toUpperCase() + selectedReportPeriod.slice(1)} Outflow`}
                size={200}
                strokeWidth={24}
              />
            </View>
          </View>
        )}

        {/* Recent Transactions Section */}
        <View style={styles.sectionHeaderRow}>
          <Text style={styles.sectionTitle}>Recent Transactions</Text>
          {isCustomer && (
            <TouchableOpacity onPress={() => navigation.navigate('MainTabs', { screen: 'TransactionsTab' })}>
              <Text style={styles.viewAllText}>View All ({transactions.length})</Text>
            </TouchableOpacity>
          )}
        </View>

        {recentTransactions.length === 0 ? (
          <EmptyState
            icon="receipt-outline"
            title="No Transactions Available"
            description="You don't have any recorded transactions yet. Tap below to log your first income or expense."
            actionTitle={isCustomer ? 'Add Transaction' : null}
            onActionPress={
              isCustomer ? () => navigation.navigate('TransactionForm', { mode: 'create' }) : null
            }
          />
        ) : (
          recentTransactions.map((tx) => (
            <TransactionItem
              key={tx.id}
              transaction={tx}
              showActions={isCustomer}
              onPress={
                isCustomer
                  ? () => navigation.navigate('TransactionForm', { mode: 'edit', transaction: tx })
                  : null
              }
              onEdit={
                isCustomer
                  ? () => navigation.navigate('TransactionForm', { mode: 'edit', transaction: tx })
                  : null
              }
              onDelete={isCustomer ? () => handleDeleteTransaction(tx) : null}
            />
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
    paddingTop: Platform.OS === 'android' ? 30 : 0,
  },
  scrollContent: {
    paddingBottom: 40,
  },
  headerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  drawerToggleBtn: {
    padding: 6,
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  brandTitleWrap: {
    alignItems: 'center',
  },
  brandAppName: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.primary,
    letterSpacing: -0.5,
  },
  welcomeText: {
    fontSize: 12,
    color: colors.textSecondary,
    fontWeight: '500',
  },
  userNameHighlight: {
    color: colors.textPrimary,
    fontWeight: '700',
  },
  avatarBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  adminBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F3FF',
    marginHorizontal: 16,
    marginBottom: 8,
    padding: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#DDD6FE',
    gap: 8,
  },
  adminBannerText: {
    fontSize: 12,
    color: colors.badgeAdmin,
    fontWeight: '600',
    flex: 1,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginTop: 18,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  sectionSubtitle: {
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: '500',
    marginTop: 2,
  },
  viewAllText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.primary,
  },
  segmentWrap: {
    paddingHorizontal: 16,
  },
  statsGrid: {
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  gridRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  adminAnalyticsWrap: {
    marginTop: 4,
    marginBottom: 8,
  },
  chartSectionWrap: {
    paddingHorizontal: 16,
  },
  donutCardContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 16,
    marginHorizontal: 16,
    marginTop: 6,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
});

export default HomeScreen;
