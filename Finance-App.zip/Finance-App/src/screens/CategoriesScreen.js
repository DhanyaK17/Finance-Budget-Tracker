import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  Platform,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTransactions } from '../context/TransactionContext';
import { useAuth } from '../context/AuthContext';
import { colors } from '../theme/colors';
import { CATEGORIES } from '../data/categories';
import { CategoryCard } from '../components/CategoryCard';
import { AppButton } from '../components/AppButton';
import { calculateCategoryBreakdown } from '../utils/calculations';
import { formatCurrency } from '../utils/currency';

export const CategoriesScreen = ({ navigation }) => {
  const { transactions } = useTransactions();
  const { isAdmin } = useAuth();
  const [selectedType, setSelectedType] = useState('expense'); // 'expense' | 'income'

  // Route protection
  if (isAdmin) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.restrictedContainer}>
          <Ionicons name="lock-closed" size={64} color={colors.expense} />
          <Text style={styles.restrictedTitle}>Access Restricted</Text>
          <Text style={styles.restrictedText}>
            Category tracking is available to Customer accounts only.
          </Text>
          <AppButton
            title="Return to Dashboard"
            onPress={() => navigation.navigate('MainTabs', { screen: 'HomeTab' })}
            variant="primary"
            style={{ marginTop: 20 }}
          />
        </View>
      </SafeAreaView>
    );
  }

  // Calculate dynamic totals for the selected type
  const categoryStats = useMemo(() => {
    return calculateCategoryBreakdown(transactions, CATEGORIES, selectedType);
  }, [transactions, selectedType]);

  const totalAmountForType = useMemo(() => {
    return categoryStats.reduce((sum, c) => sum + (c.total || 0), 0);
  }, [categoryStats]);

  const activeCount = useMemo(() => {
    return categoryStats.filter((c) => c.count > 0).length;
  }, [categoryStats]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header Bar */}
        <View style={styles.headerBar}>
          <TouchableOpacity
            onPress={() => navigation.openDrawer()}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.drawerToggleBtn}
          >
            <Ionicons name="menu-outline" size={26} color={colors.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Categories</Text>
          <View style={{ width: 38 }} />
        </View>

        {/* Type Filter Segment */}
        <View style={styles.typeToggleWrap}>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => setSelectedType('expense')}
            style={[
              styles.typeBtn,
              selectedType === 'expense' && styles.typeBtnExpenseActive,
            ]}
          >
            <Ionicons
              name="arrow-up-circle"
              size={18}
              color={selectedType === 'expense' ? '#FFFFFF' : colors.textSecondary}
            />
            <Text
              style={[
                styles.typeBtnText,
                selectedType === 'expense' && styles.typeBtnTextActive,
              ]}
            >
              Expense Categories
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => setSelectedType('income')}
            style={[
              styles.typeBtn,
              selectedType === 'income' && styles.typeBtnIncomeActive,
            ]}
          >
            <Ionicons
              name="arrow-down-circle"
              size={18}
              color={selectedType === 'income' ? '#FFFFFF' : colors.textSecondary}
            />
            <Text
              style={[
                styles.typeBtnText,
                selectedType === 'income' && styles.typeBtnTextActive,
              ]}
            >
              Income Categories
            </Text>
          </TouchableOpacity>
        </View>

        {/* Aggregate Banner */}
        <View style={styles.aggregateCard}>
          <View>
            <Text style={styles.aggregateLabel}>
              Total {selectedType === 'expense' ? 'Expenses' : 'Inflows'}
            </Text>
            <Text
              style={[
                styles.aggregateAmount,
                { color: selectedType === 'expense' ? colors.expense : colors.income },
              ]}
            >
              {formatCurrency(totalAmountForType)}
            </Text>
          </View>
          <View style={styles.activePill}>
            <Text style={styles.activePillText}>
              {activeCount} of {categoryStats.length} active
            </Text>
          </View>
        </View>

        {/* Categories List */}
        <View style={styles.categoriesList}>
          {categoryStats.map((cat) => (
            <CategoryCard
              key={cat.id}
              category={cat}
              onPress={() =>
                navigation.navigate('CategoryDetails', {
                  categoryId: cat.id,
                  categoryType: selectedType,
                })
              }
            />
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
    paddingTop: Platform.OS === 'android' ? 30 : 0,
  },
  scrollContent: {
    paddingHorizontal: 16,
    paddingBottom: 40,
  },
  headerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
  },
  drawerToggleBtn: {
    padding: 6,
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  typeToggleWrap: {
    flexDirection: 'row',
    backgroundColor: '#F1F5F9',
    borderRadius: 14,
    padding: 4,
    marginVertical: 10,
  },
  typeBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 10,
    gap: 6,
  },
  typeBtnExpenseActive: {
    backgroundColor: colors.expense,
  },
  typeBtnIncomeActive: {
    backgroundColor: colors.income,
  },
  typeBtnText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.textSecondary,
  },
  typeBtnTextActive: {
    color: '#FFFFFF',
  },
  aggregateCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
  },
  aggregateLabel: {
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: '600',
    marginBottom: 4,
  },
  aggregateAmount: {
    fontSize: 22,
    fontWeight: '800',
  },
  activePill: {
    backgroundColor: colors.primaryMuted,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 20,
  },
  activePillText: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.primary,
  },
  categoriesList: {
    marginTop: 6,
  },
  restrictedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  restrictedTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
    marginTop: 16,
    marginBottom: 8,
  },
  restrictedText: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
  },
});

export default CategoriesScreen;
