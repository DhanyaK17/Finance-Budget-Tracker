import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  Keyboard,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { colors } from '../theme/colors';
import { AppButton } from '../components/AppButton';
import { AppInput } from '../components/AppInput';
import {
  validateEmail,
  validateName,
  validatePhone,
  validatePassword,
} from '../utils/validation';

export const SignUpScreen = ({ navigation }) => {
  const { signup } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [generalError, setGeneralError] = useState('');

  const handleSignUp = async () => {
    Keyboard.dismiss();
    if (isLoading) return;
    setGeneralError('');
    const newErrors = {};

    const nameCheck = validateName(name);
    if (!nameCheck.isValid) newErrors.name = nameCheck.message;

    const emailCheck = validateEmail(email);
    if (!emailCheck.isValid) newErrors.email = emailCheck.message;

    const phoneCheck = validatePhone(phone);
    if (!phoneCheck.isValid) newErrors.phone = phoneCheck.message;

    const passCheck = validatePassword(password);
    if (!passCheck.isValid) newErrors.password = passCheck.message;

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsLoading(true);

    try {
      const res = await signup({ name, email, phone, password });
      if (!res.success) {
        setGeneralError(res.message);
      }
    } catch (e) {
      setGeneralError('Registration failed. Please check your inputs.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      enabled={Platform.OS === 'ios'}
      style={styles.keyboardContainer}
    >
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
      >
        <TouchableOpacity
          onPress={() => {
            Keyboard.dismiss();
            navigation.goBack();
          }}
          style={styles.backBtn}
        >
          <Ionicons name="arrow-back" size={22} color={colors.textPrimary} />
          <Text style={styles.backBtnText}>Back to Sign In</Text>
        </TouchableOpacity>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Create Account</Text>
          <Text style={styles.cardSubtitle}>
            Join FinTrack to manage personal budgets and track expenses effortlessly.
          </Text>

          {generalError ? (
            <View style={styles.errorBanner}>
              <Ionicons name="alert-circle" size={18} color={colors.expense} />
              <Text style={styles.errorBannerText}>{generalError}</Text>
            </View>
          ) : null}

          <AppInput
            label="Full Name *"
            placeholder="e.g. Dhanya"
            value={name}
            onChangeText={(txt) => {
              setName(txt);
              if (errors.name) setErrors((prev) => ({ ...prev, name: '' }));
            }}
            icon="person-outline"
            error={errors.name}
          />

          <AppInput
            label="Email Address *"
            placeholder="e.g. dhanya@finance.app"
            value={email}
            onChangeText={(txt) => {
              setEmail(txt);
              if (errors.email) setErrors((prev) => ({ ...prev, email: '' }));
            }}
            icon="mail-outline"
            keyboardType="email-address"
            autoCapitalize="none"
            error={errors.email}
          />

          <AppInput
            label="Phone Number *"
            placeholder="e.g. +91 98765 43210"
            value={phone}
            onChangeText={(txt) => {
              setPhone(txt);
              if (errors.phone) setErrors((prev) => ({ ...prev, phone: '' }));
            }}
            icon="call-outline"
            keyboardType="phone-pad"
            error={errors.phone}
          />

          <AppInput
            label="Password *"
            placeholder="At least 6 characters"
            value={password}
            onChangeText={(txt) => {
              setPassword(txt);
              if (errors.password) setErrors((prev) => ({ ...prev, password: '' }));
            }}
            icon="lock-closed-outline"
            secureTextEntry
            error={errors.password}
          />

          <AppButton
            title="Create Account"
            onPress={handleSignUp}
            variant="primary"
            size="lg"
            loading={isLoading}
            style={styles.signUpBtn}
          />

          <View style={styles.signInPrompt}>
            <Text style={styles.signInPromptText}>Already have an account? </Text>
            <TouchableOpacity
              onPress={() => {
                Keyboard.dismiss();
                navigation.navigate('SignIn');
              }}
            >
              <Text style={styles.signInLinkText}>Sign In</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  keyboardContainer: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    flexGrow: 1,
    padding: 20,
    paddingTop: 44,
  },
  backBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 18,
    gap: 6,
  },
  backBtnText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    padding: 24,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 4,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  cardSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    marginBottom: 20,
    lineHeight: 18,
  },
  errorBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEF2F2',
    padding: 10,
    borderRadius: 10,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#FCA5A5',
  },
  errorBannerText: {
    fontSize: 12,
    color: colors.expense,
    marginLeft: 8,
    fontWeight: '500',
    flex: 1,
  },
  signUpBtn: {
    marginTop: 8,
  },
  signInPrompt: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  signInPromptText: {
    fontSize: 13,
    color: colors.textSecondary,
  },
  signInLinkText: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.primary,
  },
});

export default SignUpScreen;
