import React, { useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  Platform,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTransactions } from '../context/TransactionContext';
import { useAuth } from '../context/AuthContext';
import { colors } from '../theme/colors';
import { getCategoryById } from '../data/categories';
import { TransactionItem } from '../components/TransactionItem';
import { EmptyState } from '../components/EmptyState';
import { AppButton } from '../components/AppButton';
import { formatCurrency } from '../utils/currency';

export const CategoryDetailsScreen = ({ route, navigation }) => {
  const { transactions, deleteTransaction } = useTransactions();
  const { isAdmin } = useAuth();

  const categoryId = route.params?.categoryId || 'food';
  const category = getCategoryById(categoryId);

  // Route protection
  if (isAdmin) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.restrictedContainer}>
          <Ionicons name="lock-closed" size={64} color={colors.expense} />
          <Text style={styles.restrictedTitle}>Access Restricted</Text>
          <Text style={styles.restrictedText}>
            Category transaction breakdown is restricted to Customer accounts.
          </Text>
          <AppButton
            title="Return to Dashboard"
            onPress={() => navigation.navigate('MainTabs', { screen: 'HomeTab' })}
            variant="primary"
            style={{ marginTop: 20 }}
          />
        </View>
      </SafeAreaView>
    );
  }

  // Filter transactions belonging to this category
  const categoryTransactions = useMemo(() => {
    return transactions.filter((t) => t.categoryId === categoryId);
  }, [transactions, categoryId]);

  // Total for this category
  const categoryTotal = useMemo(() => {
    return categoryTransactions.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
  }, [categoryTransactions]);

  // Overall type total for percentage computation
  const overallTypeTotal = useMemo(() => {
    return transactions
      .filter((t) => t.type === category.type)
      .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
  }, [transactions, category.type]);

  const percentage =
    overallTypeTotal > 0 ? ((categoryTotal / overallTypeTotal) * 100).toFixed(1) : '0';

  const handleDelete = (tx) => {
    Alert.alert(
      'Delete Transaction',
      `Are you sure you want to delete "${tx.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            await deleteTransaction(tx.id);
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* Header Bar */}
      <View style={styles.headerBar}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          style={styles.backBtn}
        >
          <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{category.name}</Text>
        <TouchableOpacity
          onPress={() =>
            navigation.navigate('TransactionForm', {
              mode: 'create',
              transaction: { categoryId: category.id, type: category.type },
            })
          }
          style={styles.addBtn}
        >
          <Ionicons name="add" size={24} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Category Hero Card */}
        <View style={styles.categoryHeroCard}>
          <View style={[styles.largeIconWrap, { backgroundColor: category.bgColor }]}>
            <Ionicons name={category.icon} size={36} color={category.color} />
          </View>
          <Text style={styles.categoryName}>{category.name}</Text>
          <Text style={[styles.categoryTotalAmount, { color: category.color }]}>
            {formatCurrency(categoryTotal)}
          </Text>

          <View style={styles.badgeRow}>
            <View style={styles.statPill}>
              <Text style={styles.statPillText}>
                {categoryTransactions.length}{' '}
                {categoryTransactions.length === 1 ? 'Transaction' : 'Transactions'}
              </Text>
            </View>
            <View style={styles.statPill}>
              <Text style={styles.statPillText}>{percentage}% of all {category.type}s</Text>
            </View>
          </View>
        </View>

        {/* Transactions List */}
        <View style={styles.listHeaderRow}>
          <Text style={styles.listTitle}>Transaction History</Text>
          <Text style={styles.listCount}>{categoryTransactions.length} items</Text>
        </View>

        {categoryTransactions.length === 0 ? (
          <EmptyState
            icon={category.icon}
            title={`No ${category.name} Transactions`}
            description={`You haven't recorded any transactions under the ${category.name} category yet.`}
            actionTitle="Add Transaction"
            onActionPress={() =>
              navigation.navigate('TransactionForm', {
                mode: 'create',
                transaction: { categoryId: category.id, type: category.type },
              })
            }
          />
        ) : (
          categoryTransactions.map((tx) => (
            <TransactionItem
              key={tx.id}
              transaction={tx}
              showActions={true}
              onPress={() =>
                navigation.navigate('TransactionForm', { mode: 'edit', transaction: tx })
              }
              onEdit={() =>
                navigation.navigate('TransactionForm', { mode: 'edit', transaction: tx })
              }
              onDelete={() => handleDelete(tx)}
            />
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
    paddingTop: Platform.OS === 'android' ? 30 : 0,
  },
  headerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.cardBorder,
    backgroundColor: '#FFFFFF',
  },
  backBtn: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  addBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 3,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  categoryHeroCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
  },
  largeIconWrap: {
    width: 72,
    height: 72,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  categoryName: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  categoryTotalAmount: {
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 12,
  },
  badgeRow: {
    flexDirection: 'row',
    gap: 8,
  },
  statPill: {
    backgroundColor: '#F1F5F9',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 20,
  },
  statPillText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  listHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    paddingHorizontal: 4,
  },
  listTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  listCount: {
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: '500',
  },
  restrictedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  restrictedTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
    marginTop: 16,
    marginBottom: 8,
  },
  restrictedText: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
  },
});

export default CategoryDetailsScreen;
