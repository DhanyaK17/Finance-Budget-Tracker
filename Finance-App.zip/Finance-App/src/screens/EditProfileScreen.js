import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';
import { colors } from '../theme/colors';
import { AppButton } from '../components/AppButton';
import { AppInput } from '../components/AppInput';
import { validateName, validateEmail, validatePhone } from '../utils/validation';

export const EditProfileScreen = ({ navigation }) => {
  const { currentUser, updateProfile, isAdmin } = useAuth();
  const { showNotification } = useNotification();

  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [generalError, setGeneralError] = useState('');

  // Route protection
  if (isAdmin) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.restrictedContainer}>
          <Ionicons name="lock-closed" size={64} color={colors.expense} />
          <Text style={styles.restrictedTitle}>Access Restricted</Text>
          <Text style={styles.restrictedText}>
            Profile editing is restricted to Customer accounts.
          </Text>
          <AppButton
            title="Go Back"
            onPress={() => navigation.goBack()}
            variant="primary"
            style={{ marginTop: 20 }}
          />
        </View>
      </SafeAreaView>
    );
  }

  const handleSave = async () => {
    setGeneralError('');
    const newErrors = {};

    const nameCheck = validateName(name);
    if (!nameCheck.isValid) newErrors.name = nameCheck.message;

    const emailCheck = validateEmail(email);
    if (!emailCheck.isValid) newErrors.email = emailCheck.message;

    const phoneCheck = validatePhone(phone);
    if (!phoneCheck.isValid) newErrors.phone = phoneCheck.message;

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsLoading(true);

    try {
      const res = await updateProfile({ name, email, phone });
      if (!res.success) {
        setGeneralError(res.message);
        setIsLoading(false);
        return;
      }

      // Success notification
      showNotification({
        title: 'Profile Updated',
        message: `Your profile details have been successfully saved, ${name.trim()}!`,
        type: 'success',
      });

      Alert.alert(
        'Profile Updated',
        'Your profile changes have been saved successfully.',
        [{ text: 'OK', onPress: () => navigation.goBack() }]
      );
    } catch (e) {
      setGeneralError('Failed to update profile. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    // Check if dirty
    const isDirty =
      name !== (currentUser?.name || '') ||
      email !== (currentUser?.email || '') ||
      phone !== (currentUser?.phone || '');

    if (isDirty) {
      Alert.alert(
        'Discard Changes',
        'You have unsaved changes. Are you sure you want to cancel?',
        [
          { text: 'Keep Editing', style: 'cancel' },
          { text: 'Discard', style: 'destructive', onPress: () => navigation.goBack() },
        ]
      );
    } else {
      navigation.goBack();
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        enabled={Platform.OS === 'ios'}
        style={{ flex: 1 }}
      >
        {/* Header Bar */}
        <View style={styles.headerBar}>
          <TouchableOpacity onPress={handleCancel} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Edit Profile</Text>
          <View style={{ width: 24 }} />
        </View>

        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.card}>
            <Text style={styles.cardHeaderTitle}>Personal Information</Text>
            <Text style={styles.cardHeaderSubtitle}>
              Update your account details below. Name and email are required.
            </Text>

            {generalError ? (
              <View style={styles.errorBanner}>
                <Ionicons name="alert-circle" size={18} color={colors.expense} />
                <Text style={styles.errorBannerText}>{generalError}</Text>
              </View>
            ) : null}

            <AppInput
              label="Full Name *"
              placeholder="Enter your full name"
              value={name}
              onChangeText={(txt) => {
                setName(txt);
                if (errors.name) setErrors((prev) => ({ ...prev, name: '' }));
              }}
              icon="person-outline"
              error={errors.name}
            />

            <AppInput
              label="Email Address *"
              placeholder="user@finance.app"
              value={email}
              onChangeText={(txt) => {
                setEmail(txt);
                if (errors.email) setErrors((prev) => ({ ...prev, email: '' }));
              }}
              icon="mail-outline"
              keyboardType="email-address"
              autoCapitalize="none"
              error={errors.email}
              helperText="Must be unique and not used by another registered account."
            />

            <AppInput
              label="Phone Number *"
              placeholder="+91 98765 43210"
              value={phone}
              onChangeText={(txt) => {
                setPhone(txt);
                if (errors.phone) setErrors((prev) => ({ ...prev, phone: '' }));
              }}
              icon="call-outline"
              keyboardType="phone-pad"
              error={errors.phone}
            />

            <View style={styles.buttonRow}>
              <AppButton
                title="Cancel"
                onPress={handleCancel}
                variant="outline"
                size="md"
                style={styles.cancelBtn}
              />
              <AppButton
                title="Save Changes"
                onPress={handleSave}
                variant="primary"
                size="md"
                loading={isLoading}
                style={styles.saveBtn}
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
    paddingTop: Platform.OS === 'android' ? 30 : 0,
  },
  headerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.cardBorder,
    backgroundColor: '#FFFFFF',
  },
  backBtn: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: colors.shadowColor,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 14,
    elevation: 3,
  },
  cardHeaderTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  cardHeaderSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    marginBottom: 20,
    lineHeight: 18,
  },
  errorBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.expenseLight,
    padding: 10,
    borderRadius: 10,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#FCA5A5',
  },
  errorBannerText: {
    fontSize: 12,
    color: colors.expense,
    marginLeft: 8,
    fontWeight: '500',
    flex: 1,
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 10,
  },
  cancelBtn: {
    flex: 1,
  },
  saveBtn: {
    flex: 1.3,
  },
  restrictedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  restrictedTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
    marginTop: 16,
    marginBottom: 8,
  },
  restrictedText: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
  },
});

export default EditProfileScreen;
