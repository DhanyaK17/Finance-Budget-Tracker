import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  Platform,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTransactions } from '../context/TransactionContext';
import { useAuth } from '../context/AuthContext';
import { colors } from '../theme/colors';
import { TransactionItem } from '../components/TransactionItem';
import { EmptyState } from '../components/EmptyState';
import { AppButton } from '../components/AppButton';
import { formatMonthYear, formatDisplayDate } from '../utils/dateHelpers';
import { filterTransactionsByMonthYear, calculateTotals } from '../utils/calculations';
import { formatCurrency } from '../utils/currency';

export const TransactionsScreen = ({ navigation }) => {
  const { transactions, deleteTransaction } = useTransactions();
  const { isAdmin } = useAuth();

  // Current selected month and year
  const today = new Date();
  const [selectedYear, setSelectedYear] = useState(today.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(today.getMonth()); // 0-indexed
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all'); // 'all' | 'expense' | 'income'

  // Route protection
  if (isAdmin) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.restrictedContainer}>
          <Ionicons name="lock-closed" size={64} color={colors.expense} />
          <Text style={styles.restrictedTitle}>Access Restricted</Text>
          <Text style={styles.restrictedText}>
            Month-wise transaction logs are restricted to Customer accounts.
          </Text>
          <AppButton
            title="Return to Dashboard"
            onPress={() => navigation.navigate('MainTabs', { screen: 'HomeTab' })}
            variant="primary"
            style={{ marginTop: 20 }}
          />
        </View>
      </SafeAreaView>
    );
  }

  // Previous and Next month navigation
  const handlePrevMonth = () => {
    if (selectedMonth === 0) {
      setSelectedMonth(11);
      setSelectedYear((prev) => prev - 1);
    } else {
      setSelectedMonth((prev) => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (selectedMonth === 11) {
      setSelectedMonth(0);
      setSelectedYear((prev) => prev + 1);
    } else {
      setSelectedMonth((prev) => prev + 1);
    }
  };

  // 1. Filter by selected Month & Year
  const monthTransactions = useMemo(() => {
    return filterTransactionsByMonthYear(transactions, selectedYear, selectedMonth);
  }, [transactions, selectedYear, selectedMonth]);

  // Monthly totals
  const monthTotals = useMemo(() => {
    return calculateTotals(monthTransactions);
  }, [monthTransactions]);

  // 2. Filter by search query and type
  const filteredTransactions = useMemo(() => {
    return monthTransactions.filter((tx) => {
      // Type match
      if (typeFilter !== 'all' && tx.type !== typeFilter) return false;

      // Search match
      if (searchQuery.trim().length > 0) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = tx.title && tx.title.toLowerCase().includes(query);
        const matchesCat = tx.categoryId && tx.categoryId.toLowerCase().includes(query);
        const matchesNote = tx.note && tx.note.toLowerCase().includes(query);
        return matchesTitle || matchesCat || matchesNote;
      }

      return true;
    });
  }, [monthTransactions, typeFilter, searchQuery]);

  // Group transactions by date
  const groupedTransactions = useMemo(() => {
    const groups = {};
    for (const tx of filteredTransactions) {
      const dateKey = tx.date;
      if (!groups[dateKey]) {
        groups[dateKey] = [];
      }
      groups[dateKey].push(tx);
    }
    // Sort dates descending
    return Object.keys(groups)
      .sort((a, b) => new Date(b) - new Date(a))
      .map((date) => ({
        date,
        items: groups[date],
      }));
  }, [filteredTransactions]);

  const handleDelete = (tx) => {
    Alert.alert(
      'Delete Transaction',
      `Are you sure you want to delete "${tx.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            await deleteTransaction(tx.id);
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* Header Bar */}
      <View style={styles.headerBar}>
        <TouchableOpacity
          onPress={() => navigation.openDrawer()}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          style={styles.drawerToggleBtn}
        >
          <Ionicons name="menu-outline" size={26} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Transactions</Text>
        <TouchableOpacity
          onPress={() => navigation.navigate('TransactionForm', { mode: 'create' })}
          style={styles.addBtn}
        >
          <Ionicons name="add" size={24} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Month Selector Bar */}
        <View style={styles.monthSelectorCard}>
          <TouchableOpacity
            onPress={handlePrevMonth}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.arrowBtn}
          >
            <Ionicons name="chevron-back" size={22} color={colors.textPrimary} />
          </TouchableOpacity>

          <View style={styles.monthDisplay}>
            <Text style={styles.monthYearText}>
              {formatMonthYear(selectedYear, selectedMonth)}
            </Text>
            <Text style={styles.monthSummarySub}>
              {monthTransactions.length} records • Balance:{' '}
              {formatCurrency(monthTotals.balance)}
            </Text>
          </View>

          <TouchableOpacity
            onPress={handleNextMonth}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            style={styles.arrowBtn}
          >
            <Ionicons name="chevron-forward" size={22} color={colors.textPrimary} />
          </TouchableOpacity>
        </View>

        {/* Monthly Inflow/Outflow mini bar */}
        <View style={styles.miniStatsRow}>
          <View style={styles.miniStatItem}>
            <Text style={styles.miniStatLabel}>Income</Text>
            <Text style={styles.miniStatIncome}>{formatCurrency(monthTotals.income)}</Text>
          </View>
          <View style={styles.miniStatDivider} />
          <View style={styles.miniStatItem}>
            <Text style={styles.miniStatLabel}>Expenses</Text>
            <Text style={styles.miniStatExpense}>{formatCurrency(monthTotals.expense)}</Text>
          </View>
          <View style={styles.miniStatDivider} />
          <View style={styles.miniStatItem}>
            <Text style={styles.miniStatLabel}>Net</Text>
            <Text
              style={[
                styles.miniStatNet,
                { color: monthTotals.balance >= 0 ? colors.income : colors.expense },
              ]}
            >
              {formatCurrency(monthTotals.balance)}
            </Text>
          </View>
        </View>

        {/* Search Input Bar */}
        <View style={styles.searchContainer}>
          <Ionicons name="search-outline" size={18} color={colors.textMuted} />
          <TextInput
            placeholder="Search by title, category, or note..."
            placeholderTextColor={colors.textMuted}
            value={searchQuery}
            onChangeText={setSearchQuery}
            style={styles.searchInput}
          />
          {searchQuery ? (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <Ionicons name="close-circle" size={18} color={colors.textMuted} />
            </TouchableOpacity>
          ) : null}
        </View>

        {/* Type Filter Pills */}
        <View style={styles.filterPillsRow}>
          <TouchableOpacity
            onPress={() => setTypeFilter('all')}
            style={[styles.pill, typeFilter === 'all' && styles.pillActive]}
          >
            <Text
              style={[styles.pillText, typeFilter === 'all' && styles.pillTextActive]}
            >
              All ({monthTransactions.length})
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => setTypeFilter('expense')}
            style={[styles.pill, typeFilter === 'expense' && styles.pillActiveExpense]}
          >
            <Text
              style={[
                styles.pillText,
                typeFilter === 'expense' && styles.pillTextActiveLight,
              ]}
            >
              Expenses
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => setTypeFilter('income')}
            style={[styles.pill, typeFilter === 'income' && styles.pillActiveIncome]}
          >
            <Text
              style={[
                styles.pillText,
                typeFilter === 'income' && styles.pillTextActiveLight,
              ]}
            >
              Income
            </Text>
          </TouchableOpacity>
        </View>

        {/* Grouped Transaction List */}
        {groupedTransactions.length === 0 ? (
          <EmptyState
            icon="calendar-outline"
            title={`No transactions in ${formatMonthYear(selectedYear, selectedMonth)}`}
            description={
              searchQuery
                ? 'No transactions matched your search query. Try another term.'
                : 'No income or expense entries were recorded for this month.'
            }
            actionTitle="Add Transaction"
            onActionPress={() => navigation.navigate('TransactionForm', { mode: 'create' })}
          />
        ) : (
          groupedTransactions.map((group) => (
            <View key={group.date} style={styles.dateGroup}>
              <View style={styles.dateHeader}>
                <Ionicons name="calendar-clear-outline" size={14} color={colors.textSecondary} />
                <Text style={styles.dateHeaderText}>
                  {formatDisplayDate(group.date, { relative: true })}
                </Text>
              </View>

              {group.items.map((tx) => (
                <TransactionItem
                  key={tx.id}
                  transaction={tx}
                  showActions={true}
                  onPress={() =>
                    navigation.navigate('TransactionForm', { mode: 'edit', transaction: tx })
                  }
                  onEdit={() =>
                    navigation.navigate('TransactionForm', { mode: 'edit', transaction: tx })
                  }
                  onDelete={() => handleDelete(tx)}
                />
              ))}
            </View>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
    paddingTop: Platform.OS === 'android' ? 30 : 0,
  },
  headerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  drawerToggleBtn: {
    padding: 6,
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  addBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 4,
  },
  scrollContent: {
    paddingHorizontal: 16,
    paddingBottom: 40,
  },
  monthSelectorCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
  },
  arrowBtn: {
    padding: 8,
    borderRadius: 10,
    backgroundColor: '#F8FAFC',
  },
  monthDisplay: {
    alignItems: 'center',
  },
  monthYearText: {
    fontSize: 16,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  monthSummarySub: {
    fontSize: 11,
    color: colors.textSecondary,
    fontWeight: '500',
    marginTop: 2,
  },
  miniStatsRow: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    alignItems: 'center',
  },
  miniStatItem: {
    flex: 1,
    alignItems: 'center',
  },
  miniStatLabel: {
    fontSize: 11,
    color: colors.textMuted,
    fontWeight: '600',
    marginBottom: 2,
  },
  miniStatIncome: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.income,
  },
  miniStatExpense: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.expense,
  },
  miniStatNet: {
    fontSize: 14,
    fontWeight: '800',
  },
  miniStatDivider: {
    width: 1,
    height: 24,
    backgroundColor: colors.cardBorder,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    marginBottom: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    color: colors.textPrimary,
    marginLeft: 8,
    paddingVertical: 2,
  },
  filterPillsRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  pill: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  pillActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  pillActiveExpense: {
    backgroundColor: colors.expense,
    borderColor: colors.expense,
  },
  pillActiveIncome: {
    backgroundColor: colors.income,
    borderColor: colors.income,
  },
  pillText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  pillTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  pillTextActiveLight: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  dateGroup: {
    marginBottom: 14,
  },
  dateHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 8,
    paddingLeft: 4,
  },
  dateHeaderText: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  restrictedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  restrictedTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
    marginTop: 16,
    marginBottom: 8,
  },
  restrictedText: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
  },
});

export default TransactionsScreen;
