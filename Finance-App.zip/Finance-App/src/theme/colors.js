export const colors = {
  // Brand & Accents
  primary: '#4F46E5',        // Deep Indigo
  primaryDark: '#3730A3',
  primaryLight: '#6366F1',
  primaryMuted: '#EEF2FF',

  // Status & Financial Indicators
  income: '#10B981',         // Vibrant Emerald
  incomeLight: '#ECFDF5',
  incomeDark: '#047857',

  expense: '#EF4444',        // Coral Crimson
  expenseLight: '#FEF2F2',
  expenseDark: '#B91C1C',

  savings: '#8B5CF6',        // Violet
  savingsLight: '#F5F3FF',

  warning: '#F59E0B',        // Amber
  warningLight: '#FFFBEB',

  info: '#0EA5E9',           // Sky Blue
  infoLight: '#F0F9FF',

  // Surfaces & Backgrounds
  background: '#F8FAFC',     // Clean slate tint
  surface: '#FFFFFF',
  surfaceSubtle: '#F1F5F9',
  surfaceElevated: '#FFFFFF',
  cardBorder: '#E2E8F0',
  divider: '#EDE8E8',

  // Dark card accents (for premium balance card)
  heroStart: '#1E1B4B',      // Midnight Indigo
  heroEnd: '#312E81',
  heroAccent: '#4ADE80',

  // Typography
  textPrimary: '#0F172A',    // Very dark slate
  textSecondary: '#475569',  // Medium slate
  textMuted: '#94A3B8',      // Soft slate
  textInverted: '#FFFFFF',

  // Categorical palette
  categoryFood: '#F97316',
  categoryShopping: '#EC4899',
  categoryTransport: '#3B82F6',
  categoryBills: '#EAB308',
  categoryEntertainment: '#A855F7',
  categoryHealth: '#06B6D4',
  categoryEducation: '#6366F1',
  categoryTravel: '#14B8A6',
  categorySalary: '#10B981',
  categoryBusiness: '#3B82F6',
  categoryFreelance: '#8B5CF6',
  categoryInvestment: '#F59E0B',
  categoryGift: '#EC4899',
  categoryOther: '#64748B',

  // Badges & Pills
  badgeAdmin: '#7C3AED',
  badgeCustomer: '#0284C7',

  // Shadows
  shadowColor: '#0F172A',
  overlay: 'rgba(15, 23, 42, 0.55)',
};

export default colors;
