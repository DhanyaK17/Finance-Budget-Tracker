import React from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useAuth } from '../context/AuthContext';
import { AuthNavigator } from './AuthNavigator';
import { CustomerDrawerNavigator } from './CustomerDrawerNavigator';
import { AdminDrawerNavigator } from './AdminDrawerNavigator';
import { TransactionFormScreen } from '../screens/TransactionFormScreen';
import { EditProfileScreen } from '../screens/EditProfileScreen';
import { CategoryDetailsScreen } from '../screens/CategoryDetailsScreen';
import { colors } from '../theme/colors';

const Stack = createNativeStackNavigator();

export const RootNavigator = () => {
  const { currentUser, isAdmin, isLoading } = useAuth();

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!currentUser ? (
          <Stack.Screen name="Auth" component={AuthNavigator} />
        ) : (
          <Stack.Group>
            <Stack.Screen
              name="Main"
              component={isAdmin ? AdminDrawerNavigator : CustomerDrawerNavigator}
            />
            {/* Customer forms and details stacks */}
            <Stack.Screen
              name="TransactionForm"
              component={TransactionFormScreen}
              options={{
                presentation: 'modal',
                animation: 'slide_from_bottom',
              }}
            />
            <Stack.Screen
              name="EditProfile"
              component={EditProfileScreen}
              options={{
                animation: 'slide_from_right',
              }}
            />
            <Stack.Screen
              name="CategoryDetails"
              component={CategoryDetailsScreen}
              options={{
                animation: 'slide_from_right',
              }}
            />
          </Stack.Group>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.background,
  },
});

export default RootNavigator;
