import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { CustomerTabNavigator } from './CustomerTabNavigator';
import { CustomDrawerContent } from './CustomDrawerContent';

const Drawer = createDrawerNavigator();

export const CustomerDrawerNavigator = () => {
  return (
    <Drawer.Navigator
      drawerContent={(props) => <CustomDrawerContent {...props} />}
      screenOptions={{
        headerShown: false,
        drawerType: 'front',
        drawerStyle: {
          width: 280,
          backgroundColor: '#FFFFFF',
        },
      }}
    >
      <Drawer.Screen name="MainTabs" component={CustomerTabNavigator} />
    </Drawer.Navigator>
  );
};

export default CustomerDrawerNavigator;
