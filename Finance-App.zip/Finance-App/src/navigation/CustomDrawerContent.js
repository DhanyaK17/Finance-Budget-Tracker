import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { colors } from '../theme/colors';

export const CustomDrawerContent = ({ navigation }) => {
  const { currentUser, role, isAdmin, isCustomer, logout } = useAuth();

  const handleLogout = () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: async () => {
            navigation.closeDrawer();
            await logout();
          },
        },
      ]
    );
  };

  const initials = currentUser?.name
    ? currentUser.name
      .split(' ')
      .map((p) => p[0])
      .join('')
      .toUpperCase()
      .slice(0, 2)
    : 'US';

  return (
    <SafeAreaView style={styles.safeContainer}>
      <View style={styles.container}>
        {/* User Card Header */}
        <View style={styles.userSection}>
          <View
            style={[
              styles.avatarWrap,
              { backgroundColor: isAdmin ? colors.badgeAdmin : colors.primary },
            ]}
          >
            <Text style={styles.avatarInitials}>{initials}</Text>
          </View>
          <Text style={styles.userName} numberOfLines={1}>
            {currentUser?.name || 'User'}
          </Text>
          <Text style={styles.userEmail} numberOfLines={1}>
            {currentUser?.email || 'user@finance.app'}
          </Text>
          <View
            style={[
              styles.roleTag,
              {
                backgroundColor: isAdmin ? '#F5F3FF' : colors.primaryMuted,
                borderColor: isAdmin ? '#DDD6FE' : '#C7D2FE',
              },
            ]}
          >
            <Ionicons
              name={isAdmin ? 'shield-checkmark' : 'person'}
              size={12}
              color={isAdmin ? colors.badgeAdmin : colors.primary}
            />
            <Text
              style={[
                styles.roleTagText,
                { color: isAdmin ? colors.badgeAdmin : colors.primary },
              ]}
            >
              {isAdmin ? 'System Admin' : 'Customer Account'}
            </Text>
          </View>
        </View>

        <View style={styles.divider} />

        {/* Navigation Items */}
        <View style={styles.menuItems}>
          {/* Shared: Home */}
          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => {
              navigation.closeDrawer();
              navigation.navigate('MainTabs', { screen: 'HomeTab' });
            }}
          >
            <View style={styles.menuIconWrap}>
              <Ionicons name="home-outline" size={20} color={colors.primary} />
            </View>
            <Text style={styles.menuItemText}>Home Dashboard</Text>
          </TouchableOpacity>

          {/* Shared: Analysis */}
          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => {
              navigation.closeDrawer();
              navigation.navigate('MainTabs', { screen: 'AnalysisTab' });
            }}
          >
            <View style={styles.menuIconWrap}>
              <Ionicons name="pie-chart-outline" size={20} color={colors.primary} />
            </View>
            <Text style={styles.menuItemText}>Analysis & Reports</Text>
          </TouchableOpacity>

          {/* Customer Only Links */}
          {isCustomer && (
            <>
              <TouchableOpacity
                style={styles.menuItem}
                onPress={() => {
                  navigation.closeDrawer();
                  navigation.navigate('MainTabs', { screen: 'TransactionsTab' });
                }}
              >
                <View style={styles.menuIconWrap}>
                  <Ionicons name="swap-horizontal-outline" size={20} color={colors.primary} />
                </View>
                <Text style={styles.menuItemText}>Transactions</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.menuItem}
                onPress={() => {
                  navigation.closeDrawer();
                  navigation.navigate('MainTabs', { screen: 'CategoriesTab' });
                }}
              >
                <View style={styles.menuIconWrap}>
                  <Ionicons name="grid-outline" size={20} color={colors.primary} />
                </View>
                <Text style={styles.menuItemText}>Overall Categories</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.menuItem}
                onPress={() => {
                  navigation.closeDrawer();
                  navigation.navigate('MainTabs', { screen: 'ProfileTab' });
                }}
              >
                <View style={styles.menuIconWrap}>
                  <Ionicons name="person-outline" size={20} color={colors.primary} />
                </View>
                <Text style={styles.menuItemText}>My Profile</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.menuItem}
                onPress={() => {
                  navigation.closeDrawer();
                  navigation.navigate('EditProfile');
                }}
              >
                <View style={styles.menuIconWrap}>
                  <Ionicons name="create-outline" size={20} color={colors.primary} />
                </View>
                <Text style={styles.menuItemText}>Edit Profile</Text>
              </TouchableOpacity>
            </>
          )}
        </View>

        {/* Bottom Logout Section */}
        <View style={styles.footer}>
          <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
            <Ionicons name="log-out-outline" size={20} color={colors.expense} />
            <Text style={styles.logoutBtnText}>Sign Out</Text>
          </TouchableOpacity>
          <Text style={styles.versionText}>FinTrack Mobile v1.0.0</Text>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingVertical: 12,
    justifyContent: 'space-between',
  },
  userSection: {
    paddingVertical: 14,
    paddingHorizontal: 8,
  },
  avatarWrap: {
    width: 58,
    height: 58,
    borderRadius: 29,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
  avatarInitials: {
    fontSize: 20,
    fontWeight: '800',
    color: '#FFFFFF',
  },
  userName: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.textPrimary,
    marginBottom: 2,
  },
  userEmail: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 10,
  },
  roleTag: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 14,
    borderWidth: 1,
    gap: 4,
  },
  roleTagText: {
    fontSize: 11,
    fontWeight: '700',
  },
  divider: {
    height: 1,
    backgroundColor: '#F1F5F9',
    marginVertical: 10,
  },
  menuItems: {
    flex: 1,
    paddingTop: 8,
    gap: 4,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 11,
    paddingHorizontal: 12,
    borderRadius: 12,
  },
  menuIconWrap: {
    width: 32,
    height: 32,
    borderRadius: 10,
    backgroundColor: colors.primaryMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  menuItemText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  footer: {
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
    paddingTop: 16,
    paddingBottom: 8,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: '#FEF2F2',
    gap: 10,
    marginBottom: 12,
  },
  logoutBtnText: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.expense,
  },
  versionText: {
    fontSize: 11,
    color: colors.textMuted,
    textAlign: 'center',
  },
});

export default CustomDrawerContent;
