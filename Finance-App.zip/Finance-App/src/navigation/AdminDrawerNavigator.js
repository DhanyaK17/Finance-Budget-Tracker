import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { AdminTabNavigator } from './AdminTabNavigator';
import { CustomDrawerContent } from './CustomDrawerContent';

const Drawer = createDrawerNavigator();

export const AdminDrawerNavigator = () => {
  return (
    <Drawer.Navigator
      drawerContent={(props) => <CustomDrawerContent {...props} />}
      screenOptions={{
        headerShown: false,
        drawerType: 'front',
        drawerStyle: {
          width: 280,
          backgroundColor: '#FFFFFF',
        },
      }}
    >
      <Drawer.Screen name="MainTabs" component={AdminTabNavigator} />
    </Drawer.Navigator>
  );
};

export default AdminDrawerNavigator;
