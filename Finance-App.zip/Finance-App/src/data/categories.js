/**
 * Categories Configuration
 * Comprehensive list of Expense and Income categories with Ionicons names and colors.
 */

export const CATEGORIES = [
  // Expense Categories
  {
    id: 'food',
    name: 'Food & Dining',
    type: 'expense',
    icon: 'restaurant-outline',
    color: '#F97316',
    bgColor: '#FFF7ED',
  },
  {
    id: 'shopping',
    name: 'Shopping',
    type: 'expense',
    icon: 'bag-handle-outline',
    color: '#EC4899',
    bgColor: '#FDF2F8',
  },
  {
    id: 'transport',
    name: 'Transport',
    type: 'expense',
    icon: 'car-outline',
    color: '#3B82F6',
    bgColor: '#EFF6FF',
  },
  {
    id: 'bills',
    name: 'Bills & Utilities',
    type: 'expense',
    icon: 'receipt-outline',
    color: '#EAB308',
    bgColor: '#FEFCE8',
  },
  {
    id: 'entertainment',
    name: 'Entertainment',
    type: 'expense',
    icon: 'film-outline',
    color: '#A855F7',
    bgColor: '#FAF5FF',
  },
  {
    id: 'health',
    name: 'Health & Medical',
    type: 'expense',
    icon: 'fitness-outline',
    color: '#06B6D4',
    bgColor: '#ECFEFF',
  },
  {
    id: 'education',
    name: 'Education',
    type: 'expense',
    icon: 'school-outline',
    color: '#6366F1',
    bgColor: '#EEF2FF',
  },
  {
    id: 'travel',
    name: 'Travel & Vacations',
    type: 'expense',
    icon: 'airplane-outline',
    color: '#14B8A6',
    bgColor: '#F0FDFA',
  },
  {
    id: 'other_expense',
    name: 'Other Expense',
    type: 'expense',
    icon: 'ellipsis-horizontal-circle-outline',
    color: '#64748B',
    bgColor: '#F8FAFC',
  },

  // Income Categories
  {
    id: 'salary',
    name: 'Salary',
    type: 'income',
    icon: 'briefcase-outline',
    color: '#10B981',
    bgColor: '#ECFDF5',
  },
  {
    id: 'business',
    name: 'Business',
    type: 'income',
    icon: 'storefront-outline',
    color: '#3B82F6',
    bgColor: '#EFF6FF',
  },
  {
    id: 'freelance',
    name: 'Freelance',
    type: 'income',
    icon: 'laptop-outline',
    color: '#8B5CF6',
    bgColor: '#F5F3FF',
  },
  {
    id: 'investment',
    name: 'Investment',
    type: 'income',
    icon: 'trending-up-outline',
    color: '#F59E0B',
    bgColor: '#FFFBEB',
  },
  {
    id: 'gift',
    name: 'Gift & Grants',
    type: 'income',
    icon: 'gift-outline',
    color: '#EC4899',
    bgColor: '#FDF2F8',
  },
  {
    id: 'other_income',
    name: 'Other Income',
    type: 'income',
    icon: 'wallet-outline',
    color: '#0D9488',
    bgColor: '#F0FDFA',
  },
];

export const getCategoryById = (categoryId) => {
  return (
    CATEGORIES.find((c) => c.id === categoryId) || {
      id: categoryId || 'other',
      name: 'Uncategorized',
      type: 'expense',
      icon: 'help-circle-outline',
      color: '#64748B',
      bgColor: '#F1F5F9',
    }
  );
};

export default CATEGORIES;
