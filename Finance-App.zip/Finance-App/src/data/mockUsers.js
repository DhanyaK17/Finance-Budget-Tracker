/**
 * Mock Users Configuration
 * Predefined accounts for instant demo login and local authentication testing.
 */

export const DEFAULT_USERS = [
  {
    id: 'admin-01',
    name: 'Dhanya Kannan',
    email: 'dhanyakannan276@gmail.com',
    password: 'Dhanzz@12',
    role: 'admin',
    phone: '9791995197',
    avatar: 'shield-checkmark',
    designation: 'System Administrator',
  },
  {
    id: 'cust-dhanya',
    name: 'Dhanya',
    email: 'dhanya@finance.app',
    password: 'Customer@123',
    role: 'customer',
    phone: '+91 98765 43210',
    avatar: 'person',
    designation: 'Senior Product Designer',
  },
];

export default DEFAULT_USERS;
