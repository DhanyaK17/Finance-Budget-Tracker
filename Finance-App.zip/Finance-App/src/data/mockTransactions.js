/**
 * Mock Transactions Initial Dataset
 * Generates sensible demo transactions across multiple registered customers
 * relative to current local date so that All-Customer Analytics and
 * Daily, Weekly, and Monthly reports are populated on initial launch.
 */

import { toLocalDateString } from '../utils/dateHelpers.js';

export const generateInitialTransactions = () => {
  const now = new Date();

  // Helper to get date string offset by days
  const getDateOffset = (dayOffset) => {
    const d = new Date(now);
    d.setDate(d.getDate() + dayOffset);
    return toLocalDateString(d);
  };

  // Helper to get past month date
  const getPastMonthDate = (monthOffset, day) => {
    const d = new Date(now.getFullYear(), now.getMonth() - monthOffset, day);
    return toLocalDateString(d);
  };

  return [
    // ========================================================
    // CUSTOMER 1: Dhanya (cust-dhanya)
    // ========================================================
    // --- TODAY ---
    {
      id: 'tx-001',
      userId: 'cust-dhanya',
      title: 'Morning Cafe & Croissant',
      amount: 280,
      type: 'expense',
      categoryId: 'food',
      date: getDateOffset(0),
      note: 'Espresso with colleague at Starbucks',
    },
    {
      id: 'tx-002',
      userId: 'cust-dhanya',
      title: 'Freelance UI Consultation',
      amount: 12500,
      type: 'income',
      categoryId: 'freelance',
      date: getDateOffset(0),
      note: 'App UX audit milestone payment',
    },
    {
      id: 'tx-003',
      userId: 'cust-dhanya',
      title: 'Cab Ride to Tech Park',
      amount: 340,
      type: 'expense',
      categoryId: 'transport',
      date: getDateOffset(0),
      note: 'Uber ride',
    },

    // --- EARLIER THIS WEEK ---
    {
      id: 'tx-004',
      userId: 'cust-dhanya',
      title: 'Supermarket Grocery Run',
      amount: 2150,
      type: 'expense',
      categoryId: 'food',
      date: getDateOffset(-2),
      note: 'Weekly essentials and fresh vegetables',
    },
    {
      id: 'tx-005',
      userId: 'cust-dhanya',
      title: 'Broadband Fiber Bill',
      amount: 999,
      type: 'expense',
      categoryId: 'bills',
      date: getDateOffset(-3),
      note: 'Airtel Xstream monthly renewal',
    },
    {
      id: 'tx-006',
      userId: 'cust-dhanya',
      title: 'Movie Night & Popcorn',
      amount: 850,
      type: 'expense',
      categoryId: 'entertainment',
      date: getDateOffset(-4),
      note: 'IMAX weekend show',
    },

    // --- EARLIER THIS MONTH ---
    {
      id: 'tx-007',
      userId: 'cust-dhanya',
      title: 'Monthly Salary Credit',
      amount: 85000,
      type: 'income',
      categoryId: 'salary',
      date: getDateOffset(-15),
      note: 'Monthly salary from Acme Corp',
    },
    {
      id: 'tx-008',
      userId: 'cust-dhanya',
      title: 'Gym & Fitness Membership',
      amount: 2500,
      type: 'expense',
      categoryId: 'health',
      date: getDateOffset(-18),
      note: 'Cult.fit 3-month renewal installment',
    },
    {
      id: 'tx-009',
      userId: 'cust-dhanya',
      title: 'Online Fashion Shopping',
      amount: 3499,
      type: 'expense',
      categoryId: 'shopping',
      date: getDateOffset(-20),
      note: 'Myntra festival collection',
    },
    {
      id: 'tx-010',
      userId: 'cust-dhanya',
      title: 'Electricity & Gas Bill',
      amount: 1840,
      type: 'expense',
      categoryId: 'bills',
      date: getDateOffset(-22),
      note: 'Bescom bill payment',
    },
    {
      id: 'tx-011',
      userId: 'cust-dhanya',
      title: 'Stock Dividend Payout',
      amount: 3200,
      type: 'income',
      categoryId: 'investment',
      date: getDateOffset(-24),
      note: 'TCS dividend credited',
    },

    // --- PAST MONTHS ---
    {
      id: 'tx-012',
      userId: 'cust-dhanya',
      title: 'Previous Month Salary',
      amount: 85000,
      type: 'income',
      categoryId: 'salary',
      date: getPastMonthDate(1, 1),
      note: 'Monthly salary',
    },
    {
      id: 'tx-013',
      userId: 'cust-dhanya',
      title: 'Weekend Getaway Hotel',
      amount: 6800,
      type: 'expense',
      categoryId: 'travel',
      date: getPastMonthDate(1, 12),
      note: 'Coorg resort booking',
    },
    {
      id: 'tx-014',
      userId: 'cust-dhanya',
      title: 'Online Course Subscription',
      amount: 1999,
      type: 'expense',
      categoryId: 'education',
      date: getPastMonthDate(1, 18),
      note: 'FullStack Masterclass Udemy',
    },

    // ========================================================
    // CUSTOMER 2: Rahul Sharma (cust-rahul)
    // ========================================================
    {
      id: 'tx-101',
      userId: 'cust-rahul',
      title: 'Software Engineer Salary',
      amount: 92000,
      type: 'income',
      categoryId: 'salary',
      date: getDateOffset(-10),
      note: 'Monthly direct deposit',
    },
    {
      id: 'tx-102',
      userId: 'cust-rahul',
      title: 'Ergonomic Desk Chair',
      amount: 14500,
      type: 'expense',
      categoryId: 'shopping',
      date: getDateOffset(0),
      note: 'Featherlite chair for home office',
    },
    {
      id: 'tx-103',
      userId: 'cust-rahul',
      title: 'Gourmet Dinner with Family',
      amount: 3400,
      type: 'expense',
      categoryId: 'food',
      date: getDateOffset(-1),
      note: 'Celebration dinner',
    },
    {
      id: 'tx-104',
      userId: 'cust-rahul',
      title: 'Fuel & Car Servicing',
      amount: 4200,
      type: 'expense',
      categoryId: 'transport',
      date: getDateOffset(-5),
      note: 'Full tank fuel and periodic checkup',
    },
    {
      id: 'tx-105',
      userId: 'cust-rahul',
      title: 'Mutual Fund SIP',
      amount: 10000,
      type: 'expense',
      categoryId: 'investment',
      date: getDateOffset(-12),
      note: 'Monthly Nifty 50 index fund SIP',
    },
    {
      id: 'tx-106',
      userId: 'cust-rahul',
      title: 'Crypto Staking Rewards',
      amount: 4500,
      type: 'income',
      categoryId: 'investment',
      date: getDateOffset(-3),
      note: 'Quarterly staking yield',
    },

    // ========================================================
    // CUSTOMER 3: Priya Patel (cust-priya)
    // ========================================================
    {
      id: 'tx-201',
      userId: 'cust-priya',
      title: 'Marketing Executive Salary',
      amount: 78000,
      type: 'income',
      categoryId: 'salary',
      date: getDateOffset(-8),
      note: 'Monthly salary deposit',
    },
    {
      id: 'tx-202',
      userId: 'cust-priya',
      title: 'Flight Tickets to Mumbai',
      amount: 7800,
      type: 'expense',
      categoryId: 'travel',
      date: getDateOffset(0),
      note: 'Indigo roundtrip booking',
    },
    {
      id: 'tx-203',
      userId: 'cust-priya',
      title: 'Home Internet & Cloud Services',
      amount: 1499,
      type: 'expense',
      categoryId: 'bills',
      date: getDateOffset(-2),
      note: 'JioFiber & Google One subscription',
    },
    {
      id: 'tx-204',
      userId: 'cust-priya',
      title: 'Health Insurance Premium',
      amount: 8500,
      type: 'expense',
      categoryId: 'health',
      date: getDateOffset(-16),
      note: 'HDFC Ergo annual premium',
    },
    {
      id: 'tx-205',
      userId: 'cust-priya',
      title: 'Brand Strategy Workshop',
      amount: 22000,
      type: 'income',
      categoryId: 'business',
      date: getDateOffset(-4),
      note: 'Corporate workshop honorarium',
    },
    {
      id: 'tx-206',
      userId: 'cust-priya',
      title: 'Organic Groceries & Produce',
      amount: 3100,
      type: 'expense',
      categoryId: 'food',
      date: getDateOffset(-6),
      note: 'Nature Basket order',
    },
  ];
};

export default generateInitialTransactions;
