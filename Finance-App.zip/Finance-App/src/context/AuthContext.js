import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DEFAULT_USERS from '../data/mockUsers';

const USERS_STORAGE_KEY = '@budget_users_v1';
const CURRENT_USER_KEY = '@budget_current_user_v1';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [users, setUsers] = useState(DEFAULT_USERS);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize Auth State from AsyncStorage
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const storedUsers = await AsyncStorage.getItem(USERS_STORAGE_KEY);
        const storedCurrentUser = await AsyncStorage.getItem(CURRENT_USER_KEY);

        let activeUsers = DEFAULT_USERS;
        if (storedUsers) {
          const parsed = JSON.parse(storedUsers);
          if (Array.isArray(parsed) && parsed.length > 0) {
            activeUsers = parsed;
          }
        } else {
          // Store default users on initial launch
          await AsyncStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(DEFAULT_USERS));
        }
        setUsers(activeUsers);

        if (storedCurrentUser) {
          const parsedUser = JSON.parse(storedCurrentUser);
          // Verify user still exists in accounts list
          const existing = activeUsers.find((u) => u.id === parsedUser.id);
          if (existing) {
            setCurrentUser(existing);
          } else {
            await AsyncStorage.removeItem(CURRENT_USER_KEY);
          }
        }
      } catch (err) {
        console.error('Error initializing auth state:', err);
      } finally {
        setIsLoading(false);
      }
    };

    initializeAuth();
  }, []);

  // Login handler
  const login = useCallback(
    async (email, password) => {
      const cleanEmail = email.trim().toLowerCase();
      const user = users.find(
        (u) => u.email.toLowerCase() === cleanEmail && u.password === password
      );

      if (!user) {
        return {
          success: false,
          message: 'Invalid email address or password. Please try again.',
        };
      }

      setCurrentUser(user);
      await AsyncStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
      return { success: true, user };
    },
    [users]
  );

  // Quick demo login for Admin or Customer
  const quickDemoLogin = useCallback(
    async (role = 'customer') => {
      const targetUser = users.find((u) => u.role === role) || DEFAULT_USERS.find((u) => u.role === role);
      if (targetUser) {
        setCurrentUser(targetUser);
        await AsyncStorage.setItem(CURRENT_USER_KEY, JSON.stringify(targetUser));
        return { success: true, user: targetUser };
      }
      return { success: false, message: 'Demo user not found.' };
    },
    [users]
  );

  // Sign up new Customer
  const signup = useCallback(
    async ({ name, email, phone, password }) => {
      const cleanEmail = email.trim().toLowerCase();
      // Check duplicate email
      const isDuplicate = users.some((u) => u.email.toLowerCase() === cleanEmail);
      if (isDuplicate) {
        return {
          success: false,
          message: 'An account with this email already exists. Please sign in or use another email.',
        };
      }

      const newUser = {
        id: `cust-${Date.now()}`,
        name: name.trim(),
        email: cleanEmail,
        phone: phone ? phone.trim() : '',
        password,
        role: 'customer',
        avatar: 'person',
        designation: 'Finance Member',
      };

      const updatedUsers = [...users, newUser];
      setUsers(updatedUsers);
      setCurrentUser(newUser);

      await AsyncStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(updatedUsers));
      await AsyncStorage.setItem(CURRENT_USER_KEY, JSON.stringify(newUser));

      return { success: true, user: newUser };
    },
    [users]
  );

  // Update profile
  const updateProfile = useCallback(
    async ({ name, email, phone }) => {
      if (!currentUser) {
        return { success: false, message: 'No active user session.' };
      }

      const cleanEmail = email.trim().toLowerCase();

      // Check duplicate email against other accounts
      const emailTaken = users.some(
        (u) => u.id !== currentUser.id && u.email.toLowerCase() === cleanEmail
      );
      if (emailTaken) {
        return {
          success: false,
          message: 'This email is already registered to another account.',
        };
      }

      const updatedUser = {
        ...currentUser,
        name: name.trim(),
        email: cleanEmail,
        phone: phone ? phone.trim() : currentUser.phone,
      };

      const updatedUsers = users.map((u) => (u.id === currentUser.id ? updatedUser : u));

      setUsers(updatedUsers);
      setCurrentUser(updatedUser);

      await AsyncStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(updatedUsers));
      await AsyncStorage.setItem(CURRENT_USER_KEY, JSON.stringify(updatedUser));

      return { success: true, user: updatedUser };
    },
    [currentUser, users]
  );

  // Logout
  const logout = useCallback(async () => {
    setCurrentUser(null);
    try {
      await AsyncStorage.removeItem(CURRENT_USER_KEY);
    } catch (e) {
      console.error('Error during logout:', e);
    }
  }, []);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        role: currentUser?.role || null,
        isAdmin: currentUser?.role === 'admin',
        isCustomer: currentUser?.role === 'customer',
        isLoading,
        users,
        login,
        quickDemoLogin,
        signup,
        updateProfile,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;
