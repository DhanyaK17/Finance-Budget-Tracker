import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { generateInitialTransactions } from '../data/mockTransactions';
import { useAuth } from './AuthContext';
import { useNotification } from './NotificationContext';
import { formatCurrency } from '../utils/currency';
import { getCategoryById } from '../data/categories';

const TRANSACTIONS_STORAGE_KEY = '@budget_transactions_v1';

const TransactionContext = createContext(null);

export const TransactionProvider = ({ children }) => {
  const { currentUser, isAdmin } = useAuth();
  const { showNotification } = useNotification();
  const [allTransactions, setAllTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load transactions from AsyncStorage
  useEffect(() => {
    const loadTransactions = async () => {
      try {
        const stored = await AsyncStorage.getItem(TRANSACTIONS_STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed)) {
            setAllTransactions(parsed);
          } else {
            const initial = generateInitialTransactions();
            setAllTransactions(initial);
            await AsyncStorage.setItem(TRANSACTIONS_STORAGE_KEY, JSON.stringify(initial));
          }
        } else {
          // First launch seed
          const initial = generateInitialTransactions();
          setAllTransactions(initial);
          await AsyncStorage.setItem(TRANSACTIONS_STORAGE_KEY, JSON.stringify(initial));
        }
      } catch (err) {
        console.error('Failed to load transactions:', err);
        const fallback = generateInitialTransactions();
        setAllTransactions(fallback);
      } finally {
        setIsLoading(false);
      }
    };

    loadTransactions();
  }, []);

  // Save to AsyncStorage
  const persistTransactions = async (newList) => {
    try {
      await AsyncStorage.setItem(TRANSACTIONS_STORAGE_KEY, JSON.stringify(newList));
    } catch (e) {
      console.error('Failed to persist transactions:', e);
    }
  };

  // Filtered transactions for active role
  // Customer sees only their own; Admin sees all transactions across the platform
  const activeTransactions = useMemo(() => {
    if (!currentUser) return [];
    if (isAdmin) {
      return allTransactions;
    }
    return allTransactions.filter((t) => t.userId === currentUser.id);
  }, [allTransactions, currentUser, isAdmin]);

  // Add transaction
  const addTransaction = useCallback(
    async ({ title, amount, type, categoryId, date, note = '' }) => {
      if (!currentUser) return { success: false, message: 'User not signed in.' };

      const numAmount = Number(amount);
      const newTx = {
        id: `tx-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        userId: currentUser.id,
        title: title.trim(),
        amount: numAmount,
        type,
        categoryId,
        date,
        note: note ? note.trim() : '',
        createdAt: new Date().toISOString(),
      };

      const updated = [newTx, ...allTransactions];
      setAllTransactions(updated);
      await persistTransactions(updated);

      // Personalized Alert
      const categoryObj = getCategoryById(categoryId);
      const customerName = currentUser.name || 'there';
      const formattedAmt = formatCurrency(numAmount);
      const alertMsg = `Hi ${customerName}, your ${formattedAmt} ${categoryObj.name.toLowerCase()} ${type} has been added successfully.`;

      showNotification({
        title: 'Transaction Added',
        message: alertMsg,
        type: 'success',
      });

      return { success: true, transaction: newTx, message: alertMsg };
    },
    [allTransactions, currentUser, showNotification]
  );

  // Edit transaction
  const editTransaction = useCallback(
    async (id, updatedFields) => {
      if (!currentUser) return { success: false, message: 'User not signed in.' };

      let targetTx = null;
      const updated = allTransactions.map((t) => {
        if (t.id === id) {
          targetTx = {
            ...t,
            ...updatedFields,
            amount: updatedFields.amount !== undefined ? Number(updatedFields.amount) : t.amount,
            updatedAt: new Date().toISOString(),
          };
          return targetTx;
        }
        return t;
      });

      if (!targetTx) {
        return { success: false, message: 'Transaction not found.' };
      }

      setAllTransactions(updated);
      await persistTransactions(updated);

      // Personalized Alert
      const customerName = currentUser.name || 'there';
      const alertMsg = `Hi ${customerName}, your "${targetTx.title}" transaction has been updated successfully.`;

      showNotification({
        title: 'Transaction Updated',
        message: alertMsg,
        type: 'success',
      });

      return { success: true, transaction: targetTx, message: alertMsg };
    },
    [allTransactions, currentUser, showNotification]
  );

  // Delete transaction
  const deleteTransaction = useCallback(
    async (id) => {
      if (!currentUser) return { success: false, message: 'User not signed in.' };

      const txToDelete = allTransactions.find((t) => t.id === id);
      if (!txToDelete) {
        return { success: false, message: 'Transaction not found.' };
      }

      const updated = allTransactions.filter((t) => t.id !== id);
      setAllTransactions(updated);
      await persistTransactions(updated);

      // Personalized Alert
      const customerName = currentUser.name || 'there';
      const formattedAmt = formatCurrency(txToDelete.amount);
      const alertMsg = `Hi ${customerName}, your ${formattedAmt} "${txToDelete.title}" has been deleted successfully.`;

      showNotification({
        title: 'Transaction Deleted',
        message: alertMsg,
        type: 'warning',
      });

      return { success: true, message: alertMsg };
    },
    [allTransactions, currentUser, showNotification]
  );

  // Reset to initial demo data
  const resetToDemoData = useCallback(async () => {
    const demo = generateInitialTransactions(currentUser?.id || 'cust-dhanya');
    setAllTransactions(demo);
    await persistTransactions(demo);

    showNotification({
      title: 'Demo Data Reset',
      message: 'Sensible demo transactions have been restored.',
      type: 'info',
    });
  }, [currentUser, showNotification]);

  return (
    <TransactionContext.Provider
      value={{
        transactions: activeTransactions,
        allTransactions,
        isLoading,
        addTransaction,
        editTransaction,
        deleteTransaction,
        resetToDemoData,
      }}
    >
      {children}
    </TransactionContext.Provider>
  );
};

export const useTransactions = () => {
  const context = useContext(TransactionContext);
  if (!context) {
    throw new Error('useTransactions must be used within a TransactionProvider');
  }
  return context;
};

export default TransactionContext;
