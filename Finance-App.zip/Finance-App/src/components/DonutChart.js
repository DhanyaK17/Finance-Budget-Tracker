import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { G, Circle } from 'react-native-svg';
import { colors } from '../theme/colors';
import { formatCurrency } from '../utils/currency';

export const DonutChart = ({
  data = [],
  total = 0,
  centerTitle = 'Total Spent',
  size = 200,
  strokeWidth = 24,
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  // Filter items that have amount > 0
  const validItems = data.filter((item) => Number(item.total) > 0);

  // If no data or total is 0
  if (validItems.length === 0 || total <= 0) {
    return (
      <View style={styles.chartContainer}>
        <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
          <Svg width={size} height={size}>
            <Circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              stroke="#E2E8F0"
              strokeWidth={strokeWidth}
              fill="none"
            />
          </Svg>
          <View style={[styles.centerLabel, { width: size, height: size }]}>
            <Text style={styles.centerTitle}>{centerTitle}</Text>
            <Text style={styles.centerAmount}>₹0</Text>
          </View>
        </View>
        <Text style={styles.emptyLegendText}>No expense data for this period</Text>
      </View>
    );
  }

  // Calculate slice angles and offsets
  let accumulatedOffset = 0;
  const slices = validItems.map((item) => {
    const fraction = item.total / total;
    const strokeDasharray = `${circumference * fraction} ${circumference * (1 - fraction)}`;
    const strokeDashoffset = -accumulatedOffset;
    accumulatedOffset += circumference * fraction;

    return {
      ...item,
      strokeDasharray,
      strokeDashoffset,
    };
  });

  return (
    <View style={styles.chartContainer}>
      <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
        <Svg width={size} height={size}>
          <G rotation="-90" origin={`${size / 2}, ${size / 2}`}>
            {/* Background ring */}
            <Circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              stroke="#F1F5F9"
              strokeWidth={strokeWidth}
              fill="none"
            />
            {/* Dynamic slices */}
            {slices.map((slice, index) => (
              <Circle
                key={slice.id || index}
                cx={size / 2}
                cy={size / 2}
                r={radius}
                stroke={slice.color || colors.primary}
                strokeWidth={strokeWidth}
                strokeDasharray={slice.strokeDasharray}
                strokeDashoffset={slice.strokeDashoffset}
                strokeLinecap="round"
                fill="none"
              />
            ))}
          </G>
        </Svg>

        {/* Center label */}
        <View style={[styles.centerLabel, { width: size, height: size }]}>
          <Text style={styles.centerTitle}>{centerTitle}</Text>
          <Text style={styles.centerAmount}>{formatCurrency(total)}</Text>
        </View>
      </View>

      {/* Breakdown Legends */}
      <View style={styles.legendContainer}>
        {validItems.slice(0, 6).map((item, index) => (
          <View key={item.id || index} style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: item.color || colors.primary }]} />
            <Text style={styles.legendName} numberOfLines={1}>
              {item.name}
            </Text>
            <Text style={styles.legendPercentage}>{item.percentage}%</Text>
            <Text style={styles.legendAmount}>{formatCurrency(item.total)}</Text>
          </View>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  chartContainer: {
    alignItems: 'center',
    paddingVertical: 14,
  },
  centerLabel: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  centerTitle: {
    fontSize: 12,
    color: colors.textSecondary,
    fontWeight: '500',
    marginBottom: 4,
  },
  centerAmount: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  emptyLegendText: {
    marginTop: 12,
    fontSize: 13,
    color: colors.textMuted,
  },
  legendContainer: {
    width: '100%',
    marginTop: 20,
    gap: 8,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 8,
  },
  legendName: {
    flex: 1,
    fontSize: 13,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  legendPercentage: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.textSecondary,
    marginRight: 10,
  },
  legendAmount: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.textPrimary,
  },
});

export default DonutChart;
