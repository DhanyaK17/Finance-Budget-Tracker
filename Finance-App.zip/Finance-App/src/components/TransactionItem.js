import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { formatCurrency } from '../utils/currency';
import { formatDisplayDate } from '../utils/dateHelpers';
import { getCategoryById } from '../data/categories';

export const TransactionItem = ({
  transaction,
  onPress,
  onEdit,
  onDelete,
  showActions = true,
}) => {
  if (!transaction) return null;

  const { title, amount, type, categoryId, date, note } = transaction;
  const category = getCategoryById(categoryId);
  const isIncome = type === 'income';

  return (
    <TouchableOpacity
      activeOpacity={onPress ? 0.7 : 1}
      onPress={onPress}
      style={styles.card}
    >
      <View style={styles.contentRow}>
        {/* Category Icon */}
        <View style={[styles.iconWrap, { backgroundColor: category.bgColor || '#F1F5F9' }]}>
          <Ionicons
            name={category.icon || 'receipt-outline'}
            size={22}
            color={category.color || colors.primary}
          />
        </View>

        {/* Title, Category & Date */}
        <View style={styles.infoWrap}>
          <Text style={styles.title} numberOfLines={1}>
            {title || 'Untitled Transaction'}
          </Text>
          <View style={styles.metaRow}>
            <View style={[styles.categoryPill, { backgroundColor: category.bgColor }]}>
              <Text style={[styles.categoryText, { color: category.color }]}>
                {category.name}
              </Text>
            </View>
            <Text style={styles.dateText}>{formatDisplayDate(date)}</Text>
          </View>
          {note ? (
            <Text style={styles.noteText} numberOfLines={1}>
              {note}
            </Text>
          ) : null}
        </View>

        {/* Amount */}
        <View style={styles.amountWrap}>
          <Text
            style={[
              styles.amountText,
              { color: isIncome ? colors.income : colors.textPrimary },
            ]}
          >
            {formatCurrency(amount, { showSign: true })}
          </Text>

          {/* Quick action icons if edit/delete provided */}
          {showActions && (onEdit || onDelete) && (
            <View style={styles.actionsRow}>
              {onEdit && (
                <TouchableOpacity
                  onPress={onEdit}
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  style={styles.actionIcon}
                >
                  <Ionicons name="create-outline" size={17} color={colors.textSecondary} />
                </TouchableOpacity>
              )}
              {onDelete && (
                <TouchableOpacity
                  onPress={onDelete}
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  style={styles.actionIcon}
                >
                  <Ionicons name="trash-outline" size={17} color={colors.expense} />
                </TouchableOpacity>
              )}
            </View>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    paddingVertical: 12,
    paddingHorizontal: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
  },
  contentRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  infoWrap: {
    flex: 1,
    marginRight: 8,
  },
  title: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
  },
  categoryPill: {
    paddingVertical: 2,
    paddingHorizontal: 6,
    borderRadius: 6,
  },
  categoryText: {
    fontSize: 11,
    fontWeight: '600',
  },
  dateText: {
    fontSize: 11,
    color: colors.textMuted,
    fontWeight: '500',
  },
  noteText: {
    fontSize: 11,
    color: colors.textSecondary,
    fontStyle: 'italic',
    marginTop: 2,
  },
  amountWrap: {
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  amountText: {
    fontSize: 15,
    fontWeight: '800',
  },
  actionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
    gap: 8,
  },
  actionIcon: {
    padding: 2,
  },
});

export default TransactionItem;
