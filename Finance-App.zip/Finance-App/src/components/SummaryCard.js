import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { formatCurrency } from '../utils/currency';

export const HeroBalanceCard = ({
  balance = 0,
  income = 0,
  expense = 0,
  savingsRate = 0,
  onAddPress,
  onAnalyticsPress,
  userName = 'Member',
  role = 'customer',
}) => {
  return (
    <View style={styles.heroContainer}>
      {/* Decorative background glow circles */}
      <View style={styles.glowTop} />
      <View style={styles.glowBottom} />

      <View style={styles.cardHeader}>
        <View>
          <Text style={styles.heroSubtitle}>Total Balance</Text>
          <Text style={styles.heroBalanceText}>{formatCurrency(balance)}</Text>
        </View>
        <View style={styles.roleChip}>
          <Ionicons
            name={role === 'admin' ? 'shield-checkmark' : 'sparkles'}
            size={13}
            color="#FFFFFF"
            style={{ marginRight: 4 }}
          />
          <Text style={styles.roleChipText}>
            {role === 'admin' ? 'Admin Vault' : `${savingsRate}% Saved`}
          </Text>
        </View>
      </View>

      {/* Income & Expense Row */}
      <View style={styles.statsRow}>
        <View style={styles.statItem}>
          <View style={[styles.statIconBadge, { backgroundColor: 'rgba(16, 185, 129, 0.2)' }]}>
            <Ionicons name="arrow-down" size={16} color={colors.income} />
          </View>
          <View>
            <Text style={styles.statLabel}>Income</Text>
            <Text style={styles.statIncomeAmount}>{formatCurrency(income)}</Text>
          </View>
        </View>

        <View style={styles.statDivider} />

        <View style={styles.statItem}>
          <View style={[styles.statIconBadge, { backgroundColor: 'rgba(239, 68, 68, 0.2)' }]}>
            <Ionicons name="arrow-up" size={16} color={colors.expense} />
          </View>
          <View>
            <Text style={styles.statLabel}>Expenses</Text>
            <Text style={styles.statExpenseAmount}>{formatCurrency(expense)}</Text>
          </View>
        </View>
      </View>

      {/* Quick Action Buttons */}
      <View style={styles.actionsRow}>
        {onAddPress && (
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={onAddPress}
            style={styles.actionBtnPrimary}
          >
            <Ionicons name="add-circle" size={18} color="#FFFFFF" style={{ marginRight: 6 }} />
            <Text style={styles.actionBtnText}>Add Transaction</Text>
          </TouchableOpacity>
        )}
        {onAnalyticsPress && (
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={onAnalyticsPress}
            style={styles.actionBtnSecondary}
          >
            <Ionicons name="pie-chart-outline" size={18} color="#FFFFFF" style={{ marginRight: 6 }} />
            <Text style={styles.actionBtnText}>View Analytics</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
};

export const StatCard = ({
  title,
  amount,
  icon,
  type = 'neutral', // 'income' | 'expense' | 'savings' | 'neutral'
  subtitle,
  onPress,
}) => {
  const getColors = () => {
    switch (type) {
      case 'income':
        return {
          bg: colors.incomeLight,
          accent: colors.income,
          iconBg: 'rgba(16, 185, 129, 0.15)',
        };
      case 'expense':
        return {
          bg: colors.expenseLight,
          accent: colors.expense,
          iconBg: 'rgba(239, 68, 68, 0.15)',
        };
      case 'savings':
        return {
          bg: colors.savingsLight,
          accent: colors.savings,
          iconBg: 'rgba(139, 92, 246, 0.15)',
        };
      default:
        return {
          bg: colors.primaryMuted,
          accent: colors.primary,
          iconBg: 'rgba(79, 70, 229, 0.12)',
        };
    }
  };

  const theme = getColors();

  return (
    <TouchableOpacity
      activeOpacity={onPress ? 0.8 : 1}
      onPress={onPress}
      disabled={!onPress}
      style={[styles.statCardContainer]}
    >
      <View style={styles.statCardHeader}>
        <View style={[styles.statCardIconWrap, { backgroundColor: theme.iconBg }]}>
          <Ionicons name={icon} size={20} color={theme.accent} />
        </View>
        <Text style={styles.statCardTitle}>{title}</Text>
      </View>
      <Text style={[styles.statCardAmount, { color: theme.accent }]}>
        {formatCurrency(amount)}
      </Text>
      {subtitle ? <Text style={styles.statCardSubtitle}>{subtitle}</Text> : null}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  heroContainer: {
    backgroundColor: '#1E1B4B',
    borderRadius: 24,
    padding: 20,
    marginHorizontal: 16,
    marginVertical: 12,
    shadowColor: '#1E1B4B',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.35,
    shadowRadius: 18,
    elevation: 8,
    overflow: 'hidden',
    position: 'relative',
  },
  glowTop: {
    position: 'absolute',
    top: -40,
    right: -30,
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: 'rgba(99, 102, 241, 0.25)',
  },
  glowBottom: {
    position: 'absolute',
    bottom: -50,
    left: -20,
    width: 130,
    height: 130,
    borderRadius: 65,
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  heroSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  heroBalanceText: {
    color: '#FFFFFF',
    fontSize: 32,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  roleChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.12)',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  roleChipText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 16,
    paddingVertical: 12,
    paddingHorizontal: 14,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.08)',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  statDivider: {
    width: 1,
    height: 32,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    marginHorizontal: 10,
  },
  statIconBadge: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  statLabel: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '500',
  },
  statIncomeAmount: {
    color: '#34D399',
    fontSize: 15,
    fontWeight: '700',
  },
  statExpenseAmount: {
    color: '#F87171',
    fontSize: 15,
    fontWeight: '700',
  },
  actionsRow: {
    flexDirection: 'row',
    gap: 10,
  },
  actionBtnPrimary: {
    flex: 1,
    backgroundColor: colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 11,
    borderRadius: 14,
  },
  actionBtnSecondary: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.14)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 11,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  actionBtnText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '600',
  },

  // StatCard styles
  statCardContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
    flex: 1,
    margin: 6,
  },
  statCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  statCardIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  statCardTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textSecondary,
    flex: 1,
  },
  statCardAmount: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  statCardSubtitle: {
    fontSize: 11,
    color: colors.textMuted,
  },
});

export default { HeroBalanceCard, StatCard };
