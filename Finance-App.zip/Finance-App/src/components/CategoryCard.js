import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { formatCurrency } from '../utils/currency';

export const CategoryCard = ({ category, onPress }) => {
  if (!category) return null;

  const { name, icon, color, bgColor, total = 0, count = 0, percentage = 0 } = category;

  return (
    <TouchableOpacity
      activeOpacity={0.75}
      onPress={onPress}
      style={styles.card}
    >
      <View style={styles.topRow}>
        <View style={[styles.iconWrap, { backgroundColor: bgColor || '#F1F5F9' }]}>
          <Ionicons name={icon || 'folder-outline'} size={22} color={color || colors.primary} />
        </View>

        <View style={styles.headerInfo}>
          <Text style={styles.name} numberOfLines={1}>
            {name}
          </Text>
          <Text style={styles.countText}>
            {count} {count === 1 ? 'transaction' : 'transactions'}
          </Text>
        </View>

        <View style={styles.amountWrap}>
          <Text style={styles.amountText}>{formatCurrency(total)}</Text>
          <Text style={styles.percentageText}>{percentage}%</Text>
        </View>

        <Ionicons
          name="chevron-forward"
          size={18}
          color={colors.textMuted}
          style={styles.chevron}
        />
      </View>

      {/* Visual Percentage Progress Bar */}
      <View style={styles.progressBarTrack}>
        <View
          style={[
            styles.progressBarFill,
            {
              backgroundColor: color || colors.primary,
              width: `${Math.min(100, Math.max(0, percentage))}%`,
            },
          ]}
        />
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerInfo: {
    flex: 1,
    marginRight: 8,
  },
  name: {
    fontSize: 15,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: 2,
  },
  countText: {
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: '500',
  },
  amountWrap: {
    alignItems: 'flex-end',
    marginRight: 6,
  },
  amountText: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.textPrimary,
  },
  percentageText: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.textSecondary,
    marginTop: 2,
  },
  chevron: {
    marginLeft: 2,
  },
  progressBarTrack: {
    height: 6,
    backgroundColor: '#F1F5F9',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 3,
  },
});

export default CategoryCard;
