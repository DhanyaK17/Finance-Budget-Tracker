import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { formatCurrency } from '../utils/currency';

export const BarComparisonChart = ({ income = 0, expense = 0 }) => {
  const totalFlow = income + expense;
  const incomePercent = totalFlow > 0 ? (income / totalFlow) * 100 : 50;
  const expensePercent = totalFlow > 0 ? (expense / totalFlow) * 100 : 50;

  return (
    <View style={styles.container}>
      <Text style={styles.chartTitle}>Cash Flow Ratio</Text>

      {/* Proportion Bar */}
      <View style={styles.barTrack}>
        <View
          style={[
            styles.barSegment,
            {
              backgroundColor: colors.income,
              width: `${incomePercent}%`,
              borderTopLeftRadius: 8,
              borderBottomLeftRadius: 8,
              borderTopRightRadius: expense === 0 ? 8 : 0,
              borderBottomRightRadius: expense === 0 ? 8 : 0,
            },
          ]}
        />
        <View
          style={[
            styles.barSegment,
            {
              backgroundColor: colors.expense,
              width: `${expensePercent}%`,
              borderTopRightRadius: 8,
              borderBottomRightRadius: 8,
              borderTopLeftRadius: income === 0 ? 8 : 0,
              borderBottomLeftRadius: income === 0 ? 8 : 0,
            },
          ]}
        />
      </View>

      {/* Value Badges */}
      <View style={styles.legendRow}>
        <View style={styles.legendBlock}>
          <View style={[styles.dot, { backgroundColor: colors.income }]} />
          <View>
            <Text style={styles.legendLabel}>Total Income ({incomePercent.toFixed(0)}%)</Text>
            <Text style={styles.incomeValue}>{formatCurrency(income)}</Text>
          </View>
        </View>

        <View style={styles.legendBlock}>
          <View style={[styles.dot, { backgroundColor: colors.expense }]} />
          <View>
            <Text style={styles.legendLabel}>Total Expenses ({expensePercent.toFixed(0)}%)</Text>
            <Text style={styles.expenseValue}>{formatCurrency(expense)}</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: 12,
  },
  barTrack: {
    height: 16,
    flexDirection: 'row',
    backgroundColor: '#F1F5F9',
    borderRadius: 8,
    overflow: 'hidden',
    marginBottom: 14,
  },
  barSegment: {
    height: '100%',
  },
  legendRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  legendBlock: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginTop: 4,
    marginRight: 8,
  },
  legendLabel: {
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: '500',
    marginBottom: 2,
  },
  incomeValue: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.income,
  },
  expenseValue: {
    fontSize: 14,
    fontWeight: '800',
    color: colors.expense,
  },
});

export default BarComparisonChart;
