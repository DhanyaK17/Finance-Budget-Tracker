/**
 * Currency Formatting Utilities
 * Standardized for Indian Rupee (₹) format
 */

export const formatCurrency = (amount, options = {}) => {
  const num = Number(amount);
  if (isNaN(num)) return '₹0';

  const { showSign = false, decimals = 0 } = options;
  const isNegative = num < 0;
  const absoluteAmount = Math.abs(num);

  // Format with Indian numbering system or fallback
  let formattedNumber;
  try {
    formattedNumber = new Intl.NumberFormat('en-IN', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(absoluteAmount);
  } catch (e) {
    // Fallback if Intl is not available
    const parts = absoluteAmount.toFixed(decimals).split('.');
    let integerPart = parts[0];
    const decimalPart = parts[1] ? `.${parts[1]}` : '';
    
    // Indian comma separation: last 3 digits, then groups of 2
    const lastThree = integerPart.substring(integerPart.length - 3);
    const otherNumbers = integerPart.substring(0, integerPart.length - 3);
    if (otherNumbers !== '') {
      formattedNumber = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + lastThree + decimalPart;
    } else {
      formattedNumber = lastThree + decimalPart;
    }
  }

  if (isNegative) {
    return `-₹${formattedNumber}`;
  }
  if (showSign && num > 0) {
    return `+₹${formattedNumber}`;
  }
  return `₹${formattedNumber}`;
};

export const formatCompactCurrency = (amount) => {
  const num = Number(amount);
  if (isNaN(num)) return '₹0';

  const abs = Math.abs(num);
  const sign = num < 0 ? '-' : '';

  if (abs >= 10000000) {
    return `${sign}₹${(abs / 10000000).toFixed(1)}Cr`;
  }
  if (abs >= 100000) {
    return `${sign}₹${(abs / 100000).toFixed(1)}L`;
  }
  if (abs >= 1000) {
    return `${sign}₹${(abs / 1000).toFixed(1)}k`;
  }
  return `${sign}₹${abs.toFixed(0)}`;
};

export default { formatCurrency, formatCompactCurrency };
