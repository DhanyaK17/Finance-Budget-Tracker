/**
 * Financial Calculation Utilities
 * Safe calculations: never returns NaN or Infinity, guards against divide-by-zero.
 */

import { isToday, isThisWeek, isThisMonth, isInMonth } from './dateHelpers.js';

export const filterTransactionsByPeriod = (transactions = [], period = 'monthly') => {
  if (!Array.isArray(transactions)) return [];

  return transactions.filter((t) => {
    if (!t || !t.date) return false;
    switch (period) {
      case 'daily':
        return isToday(t.date);
      case 'weekly':
        return isThisWeek(t.date);
      case 'monthly':
        return isThisMonth(t.date);
      case 'all':
      default:
        return true;
    }
  });
};

export const filterTransactionsByMonthYear = (transactions = [], year, monthIndex) => {
  if (!Array.isArray(transactions)) return [];
  return transactions.filter((t) => t && t.date && isInMonth(t.date, year, monthIndex));
};

export const calculateTotals = (transactions = []) => {
  if (!Array.isArray(transactions)) {
    return { income: 0, expense: 0, balance: 0, savingsRate: 0, transactionCount: 0 };
  }

  let income = 0;
  let expense = 0;

  for (const t of transactions) {
    if (!t) continue;
    const amount = Number(t.amount);
    if (isNaN(amount) || amount <= 0) continue;

    if (t.type === 'income') {
      income += amount;
    } else if (t.type === 'expense') {
      expense += amount;
    }
  }

  const balance = income - expense;
  const savingsRate = income > 0 ? Math.max(0, Math.min(100, (balance / income) * 100)) : 0;

  return {
    income,
    expense,
    balance,
    savingsRate: Number(savingsRate.toFixed(1)),
    transactionCount: transactions.length,
  };
};

export const calculatePeriodReports = (transactions = []) => {
  const dailyTx = filterTransactionsByPeriod(transactions, 'daily');
  const weeklyTx = filterTransactionsByPeriod(transactions, 'weekly');
  const monthlyTx = filterTransactionsByPeriod(transactions, 'monthly');

  return {
    daily: calculateTotals(dailyTx),
    weekly: calculateTotals(weeklyTx),
    monthly: calculateTotals(monthlyTx),
  };
};

export const calculateCategoryBreakdown = (transactions = [], categories = [], filterType = 'expense') => {
  if (!Array.isArray(transactions)) return [];

  const typeTransactions = transactions.filter((t) => t && t.type === filterType);
  const totalAmountForType = typeTransactions.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);

  // Group by categoryId
  const categoryMap = {};
  for (const t of typeTransactions) {
    if (!t.categoryId) continue;
    const amt = Number(t.amount) || 0;
    if (!categoryMap[t.categoryId]) {
      categoryMap[t.categoryId] = { total: 0, count: 0, transactions: [] };
    }
    categoryMap[t.categoryId].total += amt;
    categoryMap[t.categoryId].count += 1;
    categoryMap[t.categoryId].transactions.push(t);
  }

  // Map onto categories list
  const results = categories
    .filter((cat) => cat.type === filterType)
    .map((cat) => {
      const data = categoryMap[cat.id] || { total: 0, count: 0, transactions: [] };
      const percentage =
        totalAmountForType > 0 ? (data.total / totalAmountForType) * 100 : 0;

      return {
        ...cat,
        total: data.total,
        count: data.count,
        percentage: Number(percentage.toFixed(1)),
        transactions: data.transactions,
      };
    });

  // Sort by highest amount first
  return results.sort((a, b) => b.total - a.total);
};

export default {
  filterTransactionsByPeriod,
  filterTransactionsByMonthYear,
  calculateTotals,
  calculatePeriodReports,
  calculateCategoryBreakdown,
};
