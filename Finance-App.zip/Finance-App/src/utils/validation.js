/**
 * Validation Utilities
 * Provides comprehensive form checks and user-friendly error messages.
 */

export const validateEmail = (email) => {
  if (!email || typeof email !== 'string') {
    return { isValid: false, message: 'Email address is required.' };
  }
  const trimmed = email.trim();
  if (trimmed.length === 0) {
    return { isValid: false, message: 'Email address cannot be empty.' };
  }
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmed)) {
    return { isValid: false, message: 'Please enter a valid email address (e.g., user@example.com).' };
  }
  return { isValid: true, message: '' };
};

export const validateName = (name) => {
  if (!name || typeof name !== 'string') {
    return { isValid: false, message: 'Full name is required.' };
  }
  const trimmed = name.trim();
  if (trimmed.length < 2) {
    return { isValid: false, message: 'Full name must be at least 2 characters.' };
  }
  return { isValid: true, message: '' };
};

export const validatePhone = (phone) => {
  if (!phone || typeof phone !== 'string') {
    return { isValid: false, message: 'Phone number is required.' };
  }
  const cleanPhone = phone.replace(/[\s\-\(\)\+]/g, '');
  if (cleanPhone.length < 10) {
    return { isValid: false, message: 'Please enter a valid phone number (at least 10 digits).' };
  }
  return { isValid: true, message: '' };
};

export const validatePassword = (password) => {
  if (!password || typeof password !== 'string') {
    return { isValid: false, message: 'Password is required.' };
  }
  if (password.length < 6) {
    return { isValid: false, message: 'Password must be at least 6 characters long.' };
  }
  return { isValid: true, message: '' };
};

export const validateTransaction = ({ title, amount, type, categoryId, date }) => {
  const errors = {};

  if (!title || typeof title !== 'string' || title.trim().length === 0) {
    errors.title = 'Transaction title is required.';
  }

  const numAmount = Number(amount);
  if (amount === undefined || amount === null || String(amount).trim() === '') {
    errors.amount = 'Amount is required.';
  } else if (isNaN(numAmount) || numAmount <= 0) {
    errors.amount = 'Amount must be a positive number greater than 0.';
  }

  if (!type || (type !== 'income' && type !== 'expense')) {
    errors.type = 'Please select either Income or Expense.';
  }

  if (!categoryId || String(categoryId).trim().length === 0) {
    errors.categoryId = 'Please select a valid category.';
  }

  if (!date || String(date).trim().length === 0) {
    errors.date = 'Date is required.';
  } else {
    const d = new Date(date);
    if (isNaN(d.getTime())) {
      errors.date = 'Please provide a valid date in YYYY-MM-DD format.';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

export default {
  validateEmail,
  validateName,
  validatePhone,
  validatePassword,
  validateTransaction,
};
