/**
 * Date Helper Utilities
 * Handles local date comparisons without timezone pitfalls.
 */

// Format a Date object to YYYY-MM-DD in local time
export const toLocalDateString = (date = new Date()) => {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Parse 'YYYY-MM-DD' into local Date object (at midnight)
export const parseLocalDate = (dateStr) => {
  if (!dateStr) return new Date();
  if (dateStr instanceof Date) return dateStr;
  const parts = dateStr.split('T')[0].split('-');
  if (parts.length === 3) {
    return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  }
  return new Date(dateStr);
};

// Check if a date string is today (in local device time)
export const isToday = (dateStr) => {
  if (!dateStr) return false;
  const target = toLocalDateString(parseLocalDate(dateStr));
  const today = toLocalDateString(new Date());
  return target === today;
};

// Check if a date string falls in the current week (Monday to Sunday)
export const isThisWeek = (dateStr) => {
  if (!dateStr) return false;
  const targetDate = parseLocalDate(dateStr);
  targetDate.setHours(0, 0, 0, 0);

  const now = new Date();
  now.setHours(0, 0, 0, 0);

  // Monday is 1, Sunday is 0 -> adjust so Monday is 0, Sunday is 6
  const currentDay = now.getDay();
  const diffToMonday = currentDay === 0 ? -6 : 1 - currentDay;

  const monday = new Date(now);
  monday.setDate(now.getDate() + diffToMonday);
  monday.setHours(0, 0, 0, 0);

  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  sunday.setHours(23, 59, 59, 999);

  return targetDate >= monday && targetDate <= sunday;
};

// Check if a date string falls in the current month
export const isThisMonth = (dateStr) => {
  if (!dateStr) return false;
  const targetDate = parseLocalDate(dateStr);
  const now = new Date();
  return (
    targetDate.getFullYear() === now.getFullYear() &&
    targetDate.getMonth() === now.getMonth()
  );
};

// Check if a date string falls in a specific year and month (0-indexed month)
export const isInMonth = (dateStr, year, month) => {
  if (!dateStr) return false;
  const targetDate = parseLocalDate(dateStr);
  return targetDate.getFullYear() === year && targetDate.getMonth() === month;
};

// Format a date string for display (e.g. "28 Oct 2026", "Today", "Yesterday")
export const formatDisplayDate = (dateStr, options = {}) => {
  if (!dateStr) return '';
  const d = parseLocalDate(dateStr);
  const { relative = true } = options;

  if (relative) {
    if (isToday(dateStr)) return 'Today';
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    if (toLocalDateString(d) === toLocalDateString(yesterday)) {
      return 'Yesterday';
    }
  }

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
};

// Format month and year for selectors (e.g., "October 2026")
export const formatMonthYear = (year, monthIndex) => {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  return `${months[monthIndex]} ${year}`;
};

export const getMonthName = (monthIndex, short = false) => {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  const shortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return short ? shortMonths[monthIndex] : months[monthIndex];
};

export default {
  toLocalDateString,
  parseLocalDate,
  isToday,
  isThisWeek,
  isThisMonth,
  isInMonth,
  formatDisplayDate,
  formatMonthYear,
  getMonthName,
};
