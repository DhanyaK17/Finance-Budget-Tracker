// Automated test runner in ES module format (.mjs)
import { formatCurrency, formatCompactCurrency } from './src/utils/currency.js';
import {
  toLocalDateString,
  parseLocalDate,
  isToday,
  isThisWeek,
  isThisMonth,
  formatMonthYear,
} from './src/utils/dateHelpers.js';
import {
  calculateTotals,
  calculatePeriodReports,
  calculateCategoryBreakdown,
  filterTransactionsByPeriod,
  filterTransactionsByMonthYear,
} from './src/utils/calculations.js';
import {
  validateEmail,
  validateName,
  validatePhone,
  validatePassword,
  validateTransaction,
} from './src/utils/validation.js';
import { CATEGORIES } from './src/data/categories.js';
import { generateInitialTransactions } from './src/data/mockTransactions.js';

let testsPassed = 0;
let testsFailed = 0;

function assert(condition, message) {
  if (condition) {
    testsPassed++;
    console.log(`  ✓ PASS: ${message}`);
  } else {
    testsFailed++;
    console.error(`  ✗ FAIL: ${message}`);
  }
}

console.log('--- TESTING CURRENCY FORMATTING ---');
assert(formatCurrency(12500) === '₹12,500', '12500 formatted to ₹12,500');
assert(formatCurrency(-500) === '-₹500', '-500 formatted to -₹500');
assert(formatCurrency(0) === '₹0', '0 formatted to ₹0');
assert(formatCurrency(500, { showSign: true }) === '+₹500', 'Positive showSign gives +₹500');
assert(formatCompactCurrency(150000).includes('L') || formatCompactCurrency(150000).includes('k'), 'Compact currency works');

console.log('\n--- TESTING DATE HELPERS ---');
const todayStr = toLocalDateString(new Date());
assert(isToday(todayStr) === true, 'Today string matches isToday');
assert(isThisWeek(todayStr) === true, 'Today matches isThisWeek');
assert(isThisMonth(todayStr) === true, 'Today matches isThisMonth');
assert(formatMonthYear(2026, 9) === 'October 2026', 'Month 9 is October 2026');

console.log('\n--- TESTING INITIAL DEMO TRANSACTIONS ---');
const demoTxs = generateInitialTransactions('test-cust');
assert(Array.isArray(demoTxs) && demoTxs.length > 10, 'Initial demo transactions generated > 10');
assert(demoTxs.some((t) => isToday(t.date)), 'At least one transaction is for Today');
assert(demoTxs.some((t) => isThisWeek(t.date)), 'At least one transaction is for This Week');
assert(demoTxs.some((t) => isThisMonth(t.date)), 'At least one transaction is for This Month');

console.log('\n--- TESTING FINANCIAL CALCULATIONS ---');
const testTxs = [
  { id: '1', amount: 10000, type: 'income', categoryId: 'salary', date: todayStr },
  { id: '2', amount: 2000, type: 'expense', categoryId: 'food', date: todayStr },
  { id: '3', amount: 500, type: 'expense', categoryId: 'transport', date: todayStr },
];
const totals = calculateTotals(testTxs);
assert(totals.income === 10000, 'Income sum is 10000');
assert(totals.expense === 2500, 'Expense sum is 2500');
assert(totals.balance === 7500, 'Balance is 7500');
assert(totals.savingsRate === 75, 'Savings rate is 75%');
assert(!isNaN(totals.savingsRate) && isFinite(totals.savingsRate), 'Savings rate is finite');

// Zero division check
const zeroTotals = calculateTotals([]);
assert(zeroTotals.savingsRate === 0, 'Zero totals savingsRate is 0');
assert(zeroTotals.income === 0, 'Zero income is 0');

console.log('\n--- TESTING CATEGORY BREAKDOWN ---');
const breakdown = calculateCategoryBreakdown(testTxs, CATEGORIES, 'expense');
assert(Array.isArray(breakdown), 'Breakdown returns array');
const foodCat = breakdown.find((c) => c.id === 'food');
assert(foodCat && foodCat.total === 2000, 'Food category total is 2000');
assert(foodCat.percentage === 80, 'Food category percentage is 80% (2000/2500)');

console.log('\n--- TESTING FORM VALIDATIONS ---');
assert(validateEmail('test@finance.app').isValid === true, 'Valid email passes');
assert(validateEmail('invalid-email').isValid === false, 'Invalid email fails');
assert(validateEmail('').isValid === false, 'Empty email fails');
assert(validateName('Dhanya').isValid === true, 'Valid name passes');
assert(validateName(' ').isValid === false, 'Empty name fails');
assert(validatePhone('+91 98765 43210').isValid === true, 'Valid phone passes');
assert(validatePhone('123').isValid === false, 'Short phone fails');
assert(validatePassword('secret123').isValid === true, 'Valid password passes');
assert(validatePassword('123').isValid === false, 'Short password fails');

const validTxCheck = validateTransaction({
  title: 'Groceries',
  amount: 450,
  type: 'expense',
  categoryId: 'food',
  date: todayStr,
});
assert(validTxCheck.isValid === true, 'Valid transaction passes check');

const invalidTxCheck = validateTransaction({
  title: '',
  amount: -50,
  type: 'invalid',
  categoryId: '',
  date: '',
});
assert(invalidTxCheck.isValid === false, 'Invalid transaction fails check');
assert(Boolean(invalidTxCheck.errors.title), 'Title error present');
assert(Boolean(invalidTxCheck.errors.amount), 'Amount error present');
assert(Boolean(invalidTxCheck.errors.type), 'Type error present');
assert(Boolean(invalidTxCheck.errors.categoryId), 'Category error present');
assert(Boolean(invalidTxCheck.errors.date), 'Date error present');

console.log(`\n========================================`);
console.log(`TEST SUMMARY: ${testsPassed} passed, ${testsFailed} failed.`);
console.log(`========================================`);

if (testsFailed > 0) {
  process.exit(1);
}
